# Ahmed Rashad Hussein — Portfolio Website

A bilingual (English / Arabic) personal website for a Senior Financial Analyst.
Built with React, TypeScript, Vite and Tailwind CSS. No server, no database, no paid services.

This guide assumes **no programming experience**. Follow the parts you need.

---

## 1. What is in this folder

```
ahmed-portfolio/
├── src/
│   ├── content/            ← ✏️  ALL THE WORDS ON THE SITE LIVE HERE
│   │   ├── profile.ts        Your name, title, intro, email, LinkedIn, jobs, certifications, tools
│   │   ├── expertise.ts      Home page focus areas, Expertise page, About biography
│   │   ├── caseStudies.ts    The three illustrative case studies and their numbers
│   │   └── ui.ts             Buttons, menu labels, headings, error messages, page titles
│   ├── pages/              One file per page (Home, About, Expertise, Portfolio, Tools, Contact)
│   ├── components/         Reusable building blocks (header, charts, calculator, cards)
│   ├── lib/                Calculations (break-even, NPV, IRR) and number formatting
│   └── index.css           Colours and fonts (the "design tokens" at the top)
├── public/                 Logo icon, social-sharing image, other static files
├── scripts/prerender.mjs   Runs automatically when the site is built (sharing previews + sitemap)
├── netlify.toml            Tells Netlify how to build the site — no need to touch it
├── package.json            List of tools the project uses — no need to touch it
└── README.md               This guide
```

**You will normally only ever edit the four files in `src/content/`.**

---

## 2. How to change your content

Every piece of text is written twice, like this:

```ts
title: { en: 'Senior Financial Analyst', ar: 'محلل مالي أول' },
```

- Change only the text **inside the quotes** `'...'`.
- Keep the commas, brackets `{ }`, and the `en:` / `ar:` labels exactly as they are.
- If your text contains an apostrophe (e.g. `Bachelor's`), wrap it in double quotes instead: `"Bachelor's degree"`.

| I want to change… | Open this file | Look for |
|---|---|---|
| Name, title, brand statement, intro | `src/content/profile.ts` | `profile` at the top |
| Email or LinkedIn link | `src/content/profile.ts` | `email:` and `linkedin:` |
| Jobs, dates, responsibilities | `src/content/profile.ts` | `experience` |
| Certifications, degree, tools, languages | `src/content/profile.ts` | `certifications`, `education`, `tools`, `languages` |
| The 97% achievement line | `src/content/profile.ts` | `achievement` |
| About page biography | `src/content/expertise.ts` | `bio` |
| Home "Where I add value" | `src/content/expertise.ts` | `focusAreas` |
| Expertise page (7 capabilities) | `src/content/expertise.ts` | `capabilities` |
| Case study text or numbers | `src/content/caseStudies.ts` | each study's `findings`, `kpis`, and `data` blocks |
| Button / menu / heading / error wording | `src/content/ui.ts` | search for the English words you see on screen |
| Browser-tab titles and Google descriptions | `src/content/ui.ts` | keys starting with `meta.` |
| Your web address (after you have one) | `src/content/profile.ts` | `siteUrl:` |
| Colours | `src/index.css` | the `@theme` block at the top |

**Case study numbers:** if you change a figure in a `data` block, also update any sentence in `findings` or `kpis` that quotes it. Case study 3's NPV, IRR and payback recalculate automatically.

**Phone number:** intentionally not shown anywhere. Add it only if you decide you want it public.

---

## 3. Preview the site on your own computer (optional)

You only need this if you want to see changes before publishing. If you publish through GitHub (Section 4, Option B) you can skip it entirely.

1. Install **Node.js** (the "LTS" version) from <https://nodejs.org>. Click through the installer with the default options.
2. Open a terminal **in this folder**:
   - **Windows:** open the folder in File Explorer, click the address bar, type `cmd`, press Enter.
   - **Mac:** right-click the folder in Finder → *New Terminal at Folder* (if missing: System Settings → Keyboard → Keyboard Shortcuts → Services → enable it).
3. Type this and press Enter (first time only, takes a minute):
   ```
   npm install
   ```
4. Start the preview:
   ```
   npm run dev
   ```
5. Open the address it shows (usually <http://localhost:5173>) in your browser. Edits you save in `src/content/` appear instantly.
6. To stop the preview, click the terminal and press `Ctrl + C`.

Other commands (you rarely need these):
- `npm run build` — makes the final website in a folder called `dist`
- `npm test` — checks the break-even and investment calculations are correct

---

## 4. Publish the site on Netlify (free)

**Netlify Free plan (checked October 2026):** $0, no card required, custom domain with free HTTPS (SSL) included. It gives **300 credits per month**. Each time you publish a new version costs **15 credits**, and visitor traffic costs **20 credits per GB**. A personal portfolio like this uses well under that: for example, 4 publishes in a month (60 credits) still leaves room for roughly 12 GB of traffic, which is many thousands of visits. If you ever run out, Netlify pauses the site until the next month — so avoid publishing dozens of tiny edits; group your changes. Paid "Personal" plan: $9/month for 1,000 credits.
Pricing changes over time, so glance at <https://www.netlify.com/pricing/> before you sign up.

### Option A — Quickest first launch (no installs, ~5 minutes)

Use the ready-made **`site-ready-to-upload`** folder that came with this project (it is the already-built website).

1. Go to <https://app.netlify.com/signup> and create a free account (signing up with your GitHub or Google account is fine).
2. Go to <https://app.netlify.com/drop>.
3. Drag the **`site-ready-to-upload`** folder onto the page.
4. Wait ~30 seconds. Netlify gives you an address like `https://random-name-123.netlify.app`. Your site is now live there.
5. To choose a nicer name: **Site configuration → General → Site details → Change site name** (e.g. `ahmed-rashad` → `ahmed-rashad.netlify.app`).

Downside: to change content later you need to rebuild the folder yourself (Section 3, then `npm run build` and drag the new `dist` folder onto your site's **Deploys** page). Option B avoids this.

### Option B — Recommended for the long term (edit in your browser, site updates itself)

You store the project on GitHub (free), and Netlify rebuilds the site every time you save a change there. You never need Node.js on your computer.

**Step 1: Put the project on GitHub**
1. Create a free account at <https://github.com/signup>.
2. Click the **+** (top right) → **New repository**. Name it `portfolio`, choose **Public** or **Private** (either works), click **Create repository**.
3. On the new page, click the link **"uploading an existing file"**.
4. Open this project folder on your computer, select **everything inside it** (except any `node_modules` or `dist` folder, if you created them), and drag it into the browser window. Make sure the `src`, `public` and `scripts` folders are included.
5. Click **Commit changes** at the bottom.

**Step 2: Connect GitHub to Netlify**
1. Log in to <https://app.netlify.com>.
2. Click **Add new project → Import an existing project → GitHub**, and allow Netlify access to your `portfolio` repository.
3. Netlify reads `netlify.toml` and fills in the settings for you (build command `npm run build`, publish directory `dist`). Click **Deploy**.
4. After 1–2 minutes the status shows **Published** and you get your `.netlify.app` address.

**Step 3: Editing later**
1. On GitHub, open `src/content/profile.ts` (or another content file).
2. Click the **pencil icon** (Edit), make your change, then **Commit changes**.
3. Netlify rebuilds automatically. Check the **Deploys** tab on Netlify; when it says *Published*, refresh your site.
4. If a deploy says **Failed**, open it and read the red lines — it is usually a missing quote or comma in the file you just edited. Fix it on GitHub and commit again; the previous version of your site stays online meanwhile.

### After the first publish (both options)

Open `src/content/profile.ts`, set `siteUrl` to your real address, for example:
```ts
siteUrl: 'https://ahmed-rashad.netlify.app',
```
and publish again. This makes LinkedIn/WhatsApp link previews show your sharing image correctly and fills in the sitemap for Google.

---

## 5. Connect your own domain (e.g. ahmedrashad.com)

1. **Buy a domain** from a registrar such as Cloudflare Registrar, Namecheap or Porkbun (often $10–15/year for `.com`). You can also buy one inside Netlify: **Domain management → Add a domain → Register a new domain**.
2. In Netlify open your site → **Domain management → Add a domain** → type your domain → **Verify** → **Add domain**.
3. Netlify then shows you what to do. Pick **one** of these:
   - **Easiest — use Netlify DNS:** Netlify shows 4 "name servers" (like `dns1.p01.nsone.net`). Log in to where you bought the domain, find **Nameservers**, choose **Custom**, paste Netlify's 4 values, save.
   - **Keep your registrar's DNS:** add the records Netlify shows on screen — typically an **A record** for the bare domain and a **CNAME record** for `www` pointing to `your-site.netlify.app`. Copy the exact values from Netlify's screen rather than from any guide.
4. Wait. Changes can take from a few minutes up to 24–48 hours.
5. Netlify turns on **HTTPS** automatically once the domain works (**Domain management → HTTPS**). If it says "waiting on DNS", just wait longer.
6. Update `siteUrl` in `src/content/profile.ts` to the new domain and publish again.

---

## 6. Checklist before you share the link

- [ ] Home page shows your name, title and both buttons work.
- [ ] Every menu item opens the right page, on desktop and on a phone (tap ☰ on phones).
- [ ] The **العربية / English** button switches language and keeps you on the same page; Arabic reads right-to-left.
- [ ] Each of the three case studies opens, shows charts, and is labelled **Illustrative data**.
- [ ] Case study 3: the Downside / Base / Upside buttons change the numbers.
- [ ] Break-even calculator: press **Load an example** → Contribution margin 20.00, ratio 40.0%, break-even 5,000 units and 250,000.00, margin of safety 100,000.00 (28.6%).
- [ ] Calculator: set variable cost equal to or above price → you see a clear explanation, not a number.
- [ ] Contact page: **Send an email** opens your mail app addressed to you; **Connect on LinkedIn** opens your profile.
- [ ] Refresh the browser on an inner page (e.g. `/ar/about`) — it still loads (no "Page not found").
- [ ] Paste your link into a LinkedIn or WhatsApp message draft — a preview card with your name appears (after `siteUrl` is set).
- [ ] Check your dates, job titles and certifications one last time against your CV.

---

## 7. Technical notes (for a developer helping you)

- **Routing:** language is the first part of the URL (`/en/...`, `/ar/...`). Unprefixed URLs redirect using the saved or browser language. `netlify.toml` rewrites unknown paths to `index.html`.
- **Prerendering:** `scripts/prerender.mjs` writes `dist/<lang>/<route>/index.html` with per-page `<title>`, description, Open Graph, canonical and `hreflang` tags, plus `sitemap.xml` and `robots.txt`. It imports the TypeScript content files directly, which needs Node ≥ 22.18.
- **Charts:** hand-written SVG/HTML (no chart library). Time-series charts read left-to-right in both languages, as is common in Arabic financial reporting; bar comparison charts and the bridge chart mirror in Arabic.
- **Numbers:** Western digits in both languages (standard in Gulf business reporting). The calculator also accepts Arabic-Indic digits (١٢٣).
- **Fonts:** IBM Plex Sans and IBM Plex Sans Arabic, bundled via `@fontsource` (no Google Fonts request).
- **Tests:** `npm test` covers break-even, NPV, IRR and payback.
- **No contact form on purpose.** If you later want one, Netlify Forms works with this setup (add a `<form data-netlify="true">`); check Netlify's pricing page for how submissions count against your credits. Formspree is an alternative.
