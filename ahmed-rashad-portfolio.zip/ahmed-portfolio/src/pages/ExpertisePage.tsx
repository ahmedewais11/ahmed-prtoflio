import { useLang } from '../i18n/LanguageContext';
import { capabilities } from '../content/expertise';
import { PageIntro } from '../components/PageIntro';
import { Button } from '../components/Button';
import { usePageMeta } from '../lib/usePageMeta';

export function ExpertisePage() {
  const { t, tr, path } = useLang();
  usePageMeta(t('meta.expertise.title'), t('meta.expertise.desc'));
  return (
    <>
      <PageIntro title={t('expertise.title')} lede={t('expertise.lede')}>
        <nav className="mt-8 flex flex-wrap gap-2" aria-label={t('expertise.title')}>
          {capabilities.map((c) => (
            <a key={c.id} href={`#${c.id}`} className="rounded-md border border-line bg-white px-3 py-1.5 text-sm text-navy-800 hover:border-navy-300">
              {tr(c.title)}
            </a>
          ))}
        </nav>
      </PageIntro>
      <div className="mx-auto max-w-6xl px-4 sm:px-6">
        {capabilities.map((c) => (
          <section key={c.id} id={c.id} className="grid gap-6 border-b border-line py-12 lg:grid-cols-[1fr_1.3fr] lg:gap-14">
            <div>
              <h2 className="text-2xl font-semibold tracking-tight text-navy-900">{tr(c.title)}</h2>
              <p className="mt-4 text-sm font-medium text-muted">{t('expertise.purpose')}</p>
              <p className="mt-1.5 text-lg leading-relaxed text-navy-800">{tr(c.purpose)}</p>
            </div>
            <div className="grid gap-6 sm:grid-cols-2">
              <div>
                <h3 className="text-sm font-medium text-muted">{t('expertise.work')}</h3>
                <ul className="mt-3 grid gap-2.5">
                  {c.work.map((w) => (
                    <li key={w.en} className="flex gap-3 leading-relaxed">
                      <span aria-hidden="true" className="mt-[0.75em] h-1 w-1 shrink-0 rounded-full bg-navy-500" />
                      {tr(w)}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="self-start rounded-md border-s-2 border-teal-700 bg-white px-4 py-3">
                <h3 className="text-sm font-medium text-muted">{t('expertise.output')}</h3>
                <p className="mt-1.5 leading-relaxed text-navy-900">{tr(c.output)}</p>
              </div>
            </div>
          </section>
        ))}
        <div className="flex flex-wrap gap-3 py-12">
          <Button to={path('/portfolio')}>{t('cta.portfolio')}</Button>
          <Button to={path('/contact')} variant="secondary">{t('cta.contact')}</Button>
        </div>
      </div>
    </>
  );
}
