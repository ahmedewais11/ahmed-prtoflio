import { Link } from 'react-router-dom';
import { useLang } from '../i18n/LanguageContext';
import { profile, certifications, tools, achievement } from '../content/profile';
import { focusAreas } from '../content/expertise';
import { caseStudies, budgetData, months } from '../content/caseStudies';
import { Button } from '../components/Button';
import { SectionTitle } from '../components/PageIntro';
import { IllustrativeBadge } from '../components/IllustrativeBadge';
import { LineChart } from '../components/charts/LineChart';
import { CasePreview } from '../components/CasePreview';
import { fmtNum, fmtSignedPct } from '../lib/format';
import { sum } from '../lib/finance';
import { usePageMeta } from '../lib/usePageMeta';

/** The hero's "management report" sheet, built from case study 2's synthetic H1 data. */
function ReportSheet() {
  const { t, lang } = useLang();
  const revA = sum(budgetData.revenueActual);
  const revB = sum(budgetData.revenueBudget.slice(0, 6));
  const expA = sum(budgetData.expenseActual);
  const expB = sum(budgetData.expenseBudget.slice(0, 6));
  const rows = [
    { label: t('home.report.revenue'), a: revA, b: revB, favourable: revA >= revB },
    { label: t('home.report.expenses'), a: expA, b: expB, favourable: expA <= expB },
    { label: t('home.report.profit'), a: revA - expA, b: revB - expB, favourable: revA - expA >= revB - expB, total: true },
  ];
  const m = months[lang].slice(0, 6);

  return (
    <div className="relative rounded-lg border border-line bg-white shadow-[0_1px_0_rgba(18,35,58,0.04),0_18px_40px_-24px_rgba(18,35,58,0.35)]">
      <div className="flex items-start justify-between gap-3 border-b border-line px-5 py-4">
        <div>
          <p className="font-semibold text-navy-900">{t('home.report.title')}</p>
          <p className="mt-0.5 text-xs text-muted">{t('unitK')}</p>
        </div>
        <IllustrativeBadge />
      </div>
      <table className="w-full text-sm tabular-nums">
        <thead>
          <tr className="text-xs text-muted">
            <th scope="col" className="px-5 pb-2 pt-3 text-start font-medium">{t('home.report.line')}</th>
            <th scope="col" className="px-2 pb-2 pt-3 text-end font-medium">{t('home.report.actual')}</th>
            <th scope="col" className="px-2 pb-2 pt-3 text-end font-medium">{t('home.report.budget')}</th>
            <th scope="col" className="px-5 pb-2 pt-3 text-end font-medium">{t('home.report.var')}</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={r.label} className={`report-row ${r.total ? 'border-t-2 border-navy-900/80 font-semibold text-navy-900' : 'border-t border-line'}`} style={{ animationDelay: `${150 + i * 120}ms` }}>
              <th scope="row" className="px-5 py-2.5 text-start font-[inherit]">{r.label}</th>
              <td className="px-2 py-2.5 text-end">{fmtNum(r.a, lang)}</td>
              <td className="px-2 py-2.5 text-end text-muted">{fmtNum(r.b, lang)}</td>
              <td className={`px-5 py-2.5 text-end ${r.favourable ? 'text-teal-800' : 'text-loss'}`}>{fmtSignedPct((r.a / r.b - 1) * 100, lang)}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="report-row border-t border-line px-5 pb-4 pt-3" style={{ animationDelay: '560ms' }}>
        <div className="mb-1 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted">
          <span>{t('home.report.trend')}</span>
          <span className="flex items-center gap-1.5"><span className="h-0.5 w-3 bg-navy-800" aria-hidden="true" />{t('c2.actual')}</span>
          <span className="flex items-center gap-1.5"><span className="h-0.5 w-3 bg-budget" aria-hidden="true" />{t('c2.budget')}</span>
        </div>
        <LineChart
          compact
          height={88}
          categories={m}
          ariaLabel={t('home.report.trend')}
          format={(v) => fmtNum(v, lang)}
          series={[
            { name: t('c2.budget'), values: budgetData.revenueBudget.slice(0, 6), color: 'var(--color-budget)', muted: true },
            { name: t('c2.actual'), values: budgetData.revenueActual, color: 'var(--color-navy-800)' },
          ]}
        />
        <p className="mt-2 text-sm leading-snug text-navy-800">{t('home.report.takeaway')}</p>
      </div>
    </div>
  );
}

export function HomePage() {
  const { t, tr, path } = useLang();
  usePageMeta(t('meta.home.title'), t('meta.home.desc'));

  return (
    <>
      {/* ---------- Hero ---------- */}
      <section className="border-b border-line">
        <div className="mx-auto grid max-w-6xl items-center gap-12 px-4 pb-16 pt-12 sm:px-6 sm:pt-16 lg:grid-cols-[1.1fr_1fr] lg:gap-16 lg:pb-24 lg:pt-20">
          <div>
            <p className="text-[0.95rem] font-medium text-teal-800">{tr(profile.title)}</p>
            <h1 className="mt-3 text-[2.6rem] font-semibold leading-[1.05] tracking-tight text-navy-900 sm:text-6xl">{tr(profile.name)}</h1>
            <p className="mt-6 max-w-xl text-xl leading-snug text-navy-800 sm:text-2xl">{tr(profile.brandStatement)}</p>
            <p className="mt-5 max-w-xl leading-relaxed text-muted">{tr(profile.intro)}</p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button to={path('/portfolio')}>{t('cta.portfolio')}</Button>
              <Button to={path('/contact')} variant="secondary">
                {t('cta.contact')}
              </Button>
            </div>
            <ul className="mt-10 flex flex-wrap gap-x-6 gap-y-2 border-t border-line pt-5 text-sm text-muted" aria-label={t('about.certs')}>
              {certifications.map((c) => (
                <li key={c.name.en} className="flex items-center gap-2">
                  <span className="font-semibold text-navy-900">{c.short}</span>
                  <span>{c.issuerShort}</span>
                </li>
              ))}
            </ul>
          </div>
          <ReportSheet />
        </div>
      </section>

      {/* ---------- Focus areas ---------- */}
      <section className="bg-navy-900 text-white" aria-labelledby="focus-title">
        <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6 lg:py-20">
          <h2 id="focus-title" className="text-2xl font-semibold tracking-tight sm:text-[1.75rem]">{t('home.focus.title')}</h2>
          <div className="mt-10 grid gap-10 md:grid-cols-3 md:gap-8">
            {focusAreas.map((f) => (
              <div key={f.title.en} className="border-t-2 border-teal-500 pt-5">
                <h3 className="text-lg font-semibold">{tr(f.title)}</h3>
                <p className="mt-3 leading-relaxed text-navy-100/85">{tr(f.body)}</p>
              </div>
            ))}
          </div>
          <Link to={path('/expertise')} className="mt-10 inline-block text-sm font-medium text-teal-100 underline decoration-teal-500/60 underline-offset-4 hover:decoration-teal-100">
            {t('cta.expertiseMore')}
          </Link>
        </div>
      </section>

      {/* ---------- Case studies ---------- */}
      <section aria-labelledby="cases-title">
        <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6 lg:py-24">
          <div className="max-w-2xl">
            <SectionTitle id="cases-title">{t('home.cases.title')}</SectionTitle>
            <p className="mt-4 leading-relaxed text-muted">{t('home.cases.lede')}</p>
          </div>
          <ul className="mt-10 border-t border-line">
            {caseStudies.map((cs) => (
              <li key={cs.slug} className="border-b border-line">
                <Link to={path(`/portfolio/${cs.slug}`)} className="group grid gap-6 py-8 sm:grid-cols-[13rem_1fr] sm:gap-10">
                  <CasePreview slug={cs.slug} />
                  <div>
                    <p className="text-sm text-teal-800">{tr(cs.focus)}</p>
                    <h3 className="mt-1.5 text-xl font-semibold text-navy-900 group-hover:text-teal-800">{tr(cs.title)}</h3>
                    <p className="mt-2 max-w-2xl leading-relaxed text-muted">{tr(cs.summary)}</p>
                    <span className="mt-3 inline-block text-sm font-medium text-navy-800 underline decoration-navy-300 underline-offset-4 group-hover:decoration-teal-700">
                      {t('cta.readCase')}
                    </span>
                  </div>
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* ---------- Credentials & tools ---------- */}
      <section className="border-y border-line bg-white" aria-labelledby="skills-title">
        <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6 lg:py-20">
          <SectionTitle id="skills-title">{t('home.skills.title')}</SectionTitle>
          <div className="mt-10 grid gap-12 lg:grid-cols-2">
            <div>
              <h3 className="text-sm font-medium text-muted">{t('about.certs')}</h3>
              <ul className="mt-3">
                {certifications.map((c) => (
                  <li key={c.name.en} className="flex flex-wrap items-baseline justify-between gap-x-4 border-b border-line py-3">
                    <span className="font-medium text-navy-900">{tr(c.name)}</span>
                    <span className="text-sm text-muted">
                      {tr(c.issuer)}, {tr(c.date)}
                    </span>
                  </li>
                ))}
              </ul>
              <p className="mt-5 text-sm text-navy-800">{tr(achievement)}</p>
            </div>
            <div>
              <h3 className="text-sm font-medium text-muted">{t('about.tools')}</h3>
              <dl className="mt-3">
                {tools.map((g) => (
                  <div key={g.group.en} className="border-b border-line py-3">
                    <dt className="text-sm text-muted">{tr(g.group)}</dt>
                    <dd className="mt-2 flex flex-wrap gap-2">
                      {g.items.map((i) => (
                        <span key={i} className="rounded-md bg-navy-100/70 px-2.5 py-1 text-sm text-navy-900">
                          {i}
                        </span>
                      ))}
                    </dd>
                  </div>
                ))}
              </dl>
              <Link to={path('/about')} className="mt-5 inline-block text-sm font-medium text-teal-800 underline decoration-teal-700/40 underline-offset-4 hover:decoration-teal-700">
                {t('cta.aboutMore')}
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* ---------- Closing ---------- */}
      <section>
        <div className="mx-auto flex max-w-6xl flex-col items-start gap-6 px-4 py-16 sm:px-6 md:flex-row md:items-end md:justify-between lg:py-20">
          <div className="max-w-xl">
            <SectionTitle>{t('home.closing.title')}</SectionTitle>
            <p className="mt-3 leading-relaxed text-muted">{t('home.closing.body')}</p>
          </div>
          <Button to={path('/contact')}>{t('cta.contact')}</Button>
        </div>
      </section>
    </>
  );
}
