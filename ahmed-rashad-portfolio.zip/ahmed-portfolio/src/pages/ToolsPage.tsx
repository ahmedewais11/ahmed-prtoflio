import { useLang } from '../i18n/LanguageContext';
import { PageIntro } from '../components/PageIntro';
import { BreakEvenCalculator } from '../components/BreakEvenCalculator';
import { usePageMeta } from '../lib/usePageMeta';

export function ToolsPage() {
  const { t } = useLang();
  usePageMeta(t('meta.tools.title'), t('meta.tools.desc'));
  return (
    <>
      <PageIntro title={t('tools.title')} lede={t('tools.lede')} />
      <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6 lg:py-16">
        <BreakEvenCalculator />
      </div>
    </>
  );
}
