import { Link, useParams } from 'react-router-dom';
import { useLang } from '../i18n/LanguageContext';
import { caseStudies } from '../content/caseStudies';
import { IllustrativeBadge } from '../components/IllustrativeBadge';
import { KpiCard } from '../components/KpiCard';
import { SectionTitle } from '../components/PageIntro';
import { BranchAnalysis } from '../components/case/BranchAnalysis';
import { BudgetAnalysis } from '../components/case/BudgetAnalysis';
import { InvestmentAnalysis } from '../components/case/InvestmentAnalysis';
import { fmtK, fmtPp, fmtSignedPct, fmtYears } from '../lib/format';
import { usePageMeta } from '../lib/usePageMeta';
import { NotFoundPage } from './NotFoundPage';
import type { Kpi } from '../content/caseStudies';
import type { Lang } from '../i18n/types';

const ANALYSIS: Record<string, () => React.JSX.Element> = {
  'branch-performance': BranchAnalysis,
  'budget-forecast': BudgetAnalysis,
  'cash-flow-investment': InvestmentAnalysis,
};

function formatKpi(k: Kpi, lang: Lang) {
  switch (k.format) {
    case 'k':
      return fmtK(k.value, lang);
    case 'pct':
      return fmtSignedPct(k.value, lang);
    case 'pp':
      return fmtPp(k.value, lang);
    case 'years':
      return fmtYears(k.value, lang);
  }
}

export function CaseStudyPage() {
  const { slug } = useParams();
  const { t, tr, path, lang } = useLang();
  const index = caseStudies.findIndex((c) => c.slug === slug);
  const cs = caseStudies[index];
  usePageMeta(cs ? `${tr(cs.title)} | ${t('meta.portfolio.title')}` : t('404.title'), cs ? tr(cs.summary) : t('404.body'));
  if (!cs) return <NotFoundPage />;
  const next = caseStudies[(index + 1) % caseStudies.length];
  const Analysis = ANALYSIS[cs.slug];

  return (
    <article>
      <header className="border-b border-line">
        <div className="mx-auto max-w-6xl px-4 pb-12 pt-10 sm:px-6 sm:pt-14">
          <Link to={path('/portfolio')} className="text-sm text-muted hover:text-navy-900">
            <span aria-hidden="true">{lang === 'ar' ? '→ ' : '← '}</span>
            {t('case.back')}
          </Link>
          <p className="mt-8 text-sm font-medium text-teal-800">{tr(cs.focus)}</p>
          <h1 className="mt-2 max-w-3xl text-4xl font-semibold tracking-tight text-navy-900 sm:text-5xl">{tr(cs.title)}</h1>
          <p className="mt-5 max-w-2xl text-lg leading-relaxed text-muted">{tr(cs.summary)}</p>
          <div className="mt-6 flex max-w-2xl flex-wrap items-center gap-3 rounded-md border border-teal-700/25 bg-teal-100/40 px-4 py-3">
            <IllustrativeBadge />
            <p className="text-sm text-teal-800">{t('illustrativeNote')}</p>
          </div>
        </div>
      </header>

      <div className="mx-auto max-w-6xl px-4 sm:px-6">
        {/* Context & problem */}
        <section className="grid gap-10 border-b border-line py-12 md:grid-cols-2">
          <div>
            <SectionTitle>{t('case.context')}</SectionTitle>
            <p className="mt-4 leading-relaxed">{tr(cs.context)}</p>
          </div>
          <div>
            <SectionTitle>{t('case.problem')}</SectionTitle>
            <p className="mt-4 leading-relaxed">{tr(cs.problem)}</p>
          </div>
        </section>

        {/* Approach: a real sequence, so it is numbered */}
        <section className="border-b border-line py-12">
          <SectionTitle>{t('case.approach')}</SectionTitle>
          <ol className="mt-6 grid gap-x-8 gap-y-6 md:grid-cols-2">
            {cs.approach.map((step, i) => (
              <li key={i} className="flex gap-4">
                <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-navy-900 text-sm font-semibold text-white tabular-nums">{i + 1}</span>
                <p className="leading-relaxed">{tr(step)}</p>
              </li>
            ))}
          </ol>
        </section>

        {/* Metrics */}
        {cs.kpis.length > 0 && (
          <section className="border-b border-line py-12">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <SectionTitle>{t('case.metrics')}</SectionTitle>
              <IllustrativeBadge />
            </div>
            <div className="mt-8 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-4">
              {cs.kpis.map((k) => (
                <KpiCard key={k.label.en} label={tr(k.label)} value={formatKpi(k, lang)} note={k.note ? tr(k.note) : undefined} tone={k.tone} />
              ))}
            </div>
          </section>
        )}

        {/* Analysis */}
        <section className="border-b border-line py-12">
          <SectionTitle className="mb-8">{cs.kpis.length ? t('case.analysis') : t('case.metricsAnalysis')}</SectionTitle>
          <Analysis />
        </section>

        {cs.assumptions && (
          <section className="border-b border-line py-12">
            <SectionTitle>{t('case.assumptions')}</SectionTitle>
            <ul className="mt-5 grid max-w-3xl gap-2">
              {cs.assumptions.map((a, i) => (
                <li key={i} className="flex gap-3 leading-relaxed">
                  <span aria-hidden="true" className="mt-[0.7em] h-1 w-3 shrink-0 bg-navy-300" />
                  {tr(a)}
                </li>
              ))}
            </ul>
          </section>
        )}

        {/* Findings & recommendations */}
        <section className="grid gap-12 py-12 lg:grid-cols-2">
          <div>
            <SectionTitle>{t('case.findings')}</SectionTitle>
            <ul className="mt-6 grid gap-5">
              {cs.findings.map((f, i) => (
                <li key={i} className="border-s-2 border-navy-300 ps-4 leading-relaxed">
                  {tr(f)}
                </li>
              ))}
            </ul>
          </div>
          <div className="rounded-lg bg-navy-900 p-6 text-white sm:p-8">
            <h2 className="text-2xl font-semibold tracking-tight">{t('case.recommendations')}</h2>
            <ul className="mt-6 grid gap-5">
              {cs.recommendations.map((r, i) => (
                <li key={i} className="flex gap-3 leading-relaxed text-navy-100">
                  <svg width="16" height="16" viewBox="0 0 16 16" className="mt-1 shrink-0 text-teal-500" aria-hidden="true">
                    <path d="M3 8.5l3 3 7-7" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                  <span>{tr(r)}</span>
                </li>
              ))}
            </ul>
          </div>
        </section>

        <nav className="flex flex-wrap items-center justify-between gap-4 border-t border-line py-10" aria-label={t('nav.portfolio')}>
          <Link to={path('/portfolio')} className="text-sm text-muted hover:text-navy-900">
            {t('case.back')}
          </Link>
          <Link to={path(`/portfolio/${next.slug}`)} className="group text-end">
            <span className="block text-sm text-muted">{t('case.next')}</span>
            <span className="text-lg font-semibold text-navy-900 group-hover:text-teal-800">{tr(next.title)}</span>
          </Link>
        </nav>
      </div>
    </article>
  );
}
