import { useLang } from '../i18n/LanguageContext';
import { experience, certifications, education, learning, tools, languages, achievement } from '../content/profile';
import { bio, workflow } from '../content/expertise';
import { PageIntro, SectionTitle } from '../components/PageIntro';
import { usePageMeta } from '../lib/usePageMeta';

export function AboutPage() {
  const { t, tr } = useLang();
  usePageMeta(t('meta.about.title'), t('meta.about.desc'));

  return (
    <>
      <PageIntro title={t('about.title')} lede={t('about.lede')} />

      <div className="mx-auto max-w-6xl px-4 sm:px-6">
        {/* Biography */}
        <section className="grid gap-10 border-b border-line py-14 lg:grid-cols-[1fr_20rem]">
          <div className="max-w-2xl space-y-5 text-[1.05rem] leading-relaxed">
            {bio.map((p, i) => (
              <p key={i}>{tr(p)}</p>
            ))}
          </div>
          <aside className="self-start rounded-lg border border-line bg-white p-6">
            <h2 className="text-sm font-medium text-muted">{t('about.achievement')}</h2>
            <p className="mt-2 text-4xl font-semibold tracking-tight text-navy-900 tabular-nums">97%</p>
            <p className="mt-2 text-sm leading-relaxed text-navy-800">{tr(achievement)}</p>
          </aside>
        </section>

        {/* Career timeline */}
        <section className="border-b border-line py-14" aria-labelledby="career">
          <SectionTitle id="career">{t('about.career')}</SectionTitle>
          <ol className="mt-10 border-s-2 border-navy-100">
            {experience.map((job) => (
              <li key={job.company.en} className="relative pb-12 ps-8 last:pb-0">
                <span aria-hidden="true" className="absolute -start-[7px] top-1.5 h-3 w-3 rounded-full border-2 border-ivory bg-teal-700 ring-2 ring-teal-700/30" />
                <h3 className="text-xl font-semibold text-navy-900">{tr(job.company)}</h3>
                <p className="text-sm text-muted">{tr(job.location)}</p>
                <ul className="mt-4 grid gap-2">
                  {job.roles.map((r) => (
                    <li key={r.title.en} className="flex flex-wrap items-baseline justify-between gap-x-6 gap-y-0.5 rounded-md bg-white px-4 py-2.5 sm:max-w-xl">
                      <span className="font-medium text-navy-900">{tr(r.title)}</span>
                      <span className="text-sm text-muted tabular-nums">{tr(r.period)}</span>
                    </li>
                  ))}
                </ul>
                <ul className="mt-5 grid max-w-3xl gap-x-8 gap-y-2 md:grid-cols-2">
                  {job.responsibilities.map((x) => (
                    <li key={x.en} className="flex gap-3 text-[0.95rem] leading-relaxed">
                      <span aria-hidden="true" className="mt-[0.75em] h-1 w-1 shrink-0 rounded-full bg-navy-500" />
                      {tr(x)}
                    </li>
                  ))}
                </ul>
              </li>
            ))}
          </ol>
        </section>

        {/* How the work fits together */}
        <section className="border-b border-line py-14">
          <SectionTitle>{t('about.how')}</SectionTitle>
          <p className="mt-3 max-w-2xl leading-relaxed text-muted">{t('about.how.lede')}</p>
          <ol className="mt-8 grid gap-px overflow-hidden rounded-lg border border-line bg-line sm:grid-cols-5">
            {workflow.map((w, i) => (
              <li key={w.title.en} className="bg-white p-5">
                <span className="text-sm font-semibold text-teal-800 tabular-nums">{i + 1}</span>
                <h3 className="mt-1 font-semibold text-navy-900">{tr(w.title)}</h3>
                <p className="mt-1.5 text-sm leading-relaxed text-muted">{tr(w.body)}</p>
              </li>
            ))}
          </ol>
        </section>

        {/* Certifications & education */}
        <section className="grid gap-12 border-b border-line py-14 lg:grid-cols-2">
          <div>
            <SectionTitle>{t('about.certs')}</SectionTitle>
            <ul className="mt-6">
              {certifications.map((c) => (
                <li key={c.short} className="flex gap-4 border-b border-line py-4 last:border-0">
                  <span className="grid h-12 w-14 shrink-0 place-items-center rounded-md bg-navy-900 text-xs font-semibold text-white">{c.short}</span>
                  <div>
                    <p className="font-medium text-navy-900">{tr(c.name)}</p>
                    <p className="text-sm text-muted">
                      {tr(c.issuer)}, {tr(c.date)}
                    </p>
                  </div>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <SectionTitle>{t('about.education')}</SectionTitle>
            <div className="mt-6 rounded-lg border border-line bg-white p-5">
              <p className="font-medium text-navy-900">{tr(education.degree)}</p>
              <p className="mt-1 text-sm text-muted">{tr(education.school)}</p>
              <p className="mt-1 text-sm text-muted">{tr(education.grade)}</p>
            </div>
            <h3 className="mt-8 text-sm font-medium text-muted">{t('about.learning')}</h3>
            <ul className="mt-2 grid gap-1.5">
              {learning.map((l) => (
                <li key={l.en} className="text-navy-900">{tr(l)}</li>
              ))}
            </ul>
          </div>
        </section>

        {/* Tools & languages */}
        <section className="grid gap-12 py-14 lg:grid-cols-[2fr_1fr]">
          <div>
            <SectionTitle>{t('about.tools')}</SectionTitle>
            <dl className="mt-6 grid gap-6 sm:grid-cols-3">
              {tools.map((g) => (
                <div key={g.group.en}>
                  <dt className="text-sm font-medium text-muted">{tr(g.group)}</dt>
                  <dd className="mt-2 grid gap-1.5">
                    {g.items.map((i) => (
                      <span key={i} className="text-navy-900">{i}</span>
                    ))}
                  </dd>
                </div>
              ))}
            </dl>
          </div>
          <div>
            <SectionTitle>{t('about.languages')}</SectionTitle>
            <dl className="mt-6 grid gap-3">
              {languages.map((l) => (
                <div key={l.name.en} className="flex items-baseline justify-between gap-4 border-b border-line pb-3">
                  <dt className="font-medium text-navy-900">{tr(l.name)}</dt>
                  <dd className="text-sm text-muted">{tr(l.level)}</dd>
                </div>
              ))}
            </dl>
          </div>
        </section>
      </div>
    </>
  );
}
