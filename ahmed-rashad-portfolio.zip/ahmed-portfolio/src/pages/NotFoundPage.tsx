import { useLang } from '../i18n/LanguageContext';
import { Button } from '../components/Button';
import { usePageMeta } from '../lib/usePageMeta';

export function NotFoundPage() {
  const { t, path } = useLang();
  usePageMeta(t('404.title'), t('404.body'));
  return (
    <div className="mx-auto max-w-6xl px-4 py-24 sm:px-6">
      <h1 className="text-4xl font-semibold text-navy-900">{t('404.title')}</h1>
      <p className="mt-4 text-muted">{t('404.body')}</p>
      <Button to={path('/')} className="mt-8">{t('404.home')}</Button>
    </div>
  );
}
