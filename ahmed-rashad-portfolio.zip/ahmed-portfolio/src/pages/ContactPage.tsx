import { useState } from 'react';
import { useLang } from '../i18n/LanguageContext';
import { profile } from '../content/profile';
import { PageIntro } from '../components/PageIntro';
import { usePageMeta } from '../lib/usePageMeta';
import type { UiKey } from '../content/ui';

const TOPICS: UiKey[] = ['contact.t1', 'contact.t2', 'contact.t3', 'contact.t4', 'contact.t5'];

export function ContactPage() {
  const { t, lang } = useLang();
  usePageMeta(t('meta.contact.title'), t('meta.contact.desc'));
  const [copied, setCopied] = useState(false);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(profile.email);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      /* clipboard blocked: the address is visible and selectable anyway */
    }
  };

  const subject = encodeURIComponent(lang === 'en' ? 'Enquiry from your website' : 'استفسار من موقعك');

  return (
    <>
      <PageIntro title={t('contact.title')} lede={t('contact.lede')} />
      <div className="mx-auto grid max-w-6xl gap-10 px-4 py-12 sm:px-6 lg:grid-cols-[1.3fr_1fr] lg:py-16">
        <div className="grid gap-5 self-start">
          {/* Email */}
          <div className="rounded-lg border border-line bg-white p-6">
            <h2 className="text-sm font-medium text-muted">{t('contact.email')}</h2>
            <p className="mt-2 break-all text-xl font-semibold text-navy-900 sm:text-2xl" dir="ltr">
              {profile.email}
            </p>
            <div className="mt-5 flex flex-wrap gap-3">
              <a href={`mailto:${profile.email}?subject=${subject}`} className="inline-flex items-center rounded-md bg-navy-900 px-5 py-3 text-[0.95rem] font-medium text-white hover:bg-navy-800">
                {t('cta.email')}
              </a>
              <button type="button" onClick={copy} className="inline-flex items-center rounded-md border border-navy-900/25 px-5 py-3 text-[0.95rem] font-medium text-navy-900 hover:border-navy-900">
                {copied ? t('cta.copied') : t('cta.copy')}
              </button>
              <span role="status" className="sr-only">{copied ? t('cta.copied') : ''}</span>
            </div>
          </div>
          {/* LinkedIn */}
          <div className="rounded-lg border border-line bg-white p-6">
            <h2 className="text-sm font-medium text-muted">{t('contact.linkedin')}</h2>
            <p className="mt-2 break-all text-navy-900" dir="ltr">
              {profile.linkedin.replace(/^https?:\/\/(www\.)?/, '')}
            </p>
            <a href={profile.linkedin} target="_blank" rel="noopener noreferrer" className="mt-5 inline-flex items-center rounded-md border border-navy-900/25 px-5 py-3 text-[0.95rem] font-medium text-navy-900 hover:border-navy-900">
              {t('cta.linkedin')}
              <span className="sr-only"> {t('newTab')}</span>
            </a>
          </div>
          <p className="text-sm leading-relaxed text-muted">{t('contact.hint')}</p>
        </div>

        <aside className="self-start rounded-lg bg-navy-900 p-6 text-white sm:p-8">
          <h2 className="text-xl font-semibold">{t('contact.topics')}</h2>
          <ul className="mt-5 grid gap-3">
            {TOPICS.map((k) => (
              <li key={k} className="flex gap-3 text-navy-100">
                <span aria-hidden="true" className="mt-[0.7em] h-0.5 w-3 shrink-0 bg-teal-500" />
                {t(k)}
              </li>
            ))}
          </ul>
        </aside>
      </div>
    </>
  );
}
