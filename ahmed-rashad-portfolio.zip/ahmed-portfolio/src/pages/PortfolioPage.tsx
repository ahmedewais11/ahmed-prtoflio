import { Link } from 'react-router-dom';
import { useLang } from '../i18n/LanguageContext';
import { caseStudies } from '../content/caseStudies';
import { PageIntro } from '../components/PageIntro';
import { CasePreview } from '../components/CasePreview';
import { IllustrativeBadge } from '../components/IllustrativeBadge';
import { usePageMeta } from '../lib/usePageMeta';

export function PortfolioPage() {
  const { t, tr, path } = useLang();
  usePageMeta(t('meta.portfolio.title'), t('meta.portfolio.desc'));
  return (
    <>
      <PageIntro title={t('portfolio.title')} lede={t('portfolio.lede')}>
        <div className="mt-6 flex max-w-2xl flex-wrap items-center gap-3">
          <IllustrativeBadge />
          <p className="text-sm text-muted">{t('illustrativeNote')}</p>
        </div>
      </PageIntro>
      <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6 lg:py-16">
        <ul className="grid gap-6 md:grid-cols-3">
          {caseStudies.map((cs) => (
            <li key={cs.slug}>
              <Link to={path(`/portfolio/${cs.slug}`)} className="group flex h-full flex-col rounded-lg border border-line bg-white p-5 transition-colors hover:border-navy-300">
                <CasePreview slug={cs.slug} />
                <p className="mt-5 text-sm text-teal-800">{tr(cs.focus)}</p>
                <h2 className="mt-1.5 text-xl font-semibold text-navy-900 group-hover:text-teal-800">{tr(cs.title)}</h2>
                <p className="mt-2 flex-1 leading-relaxed text-muted">{tr(cs.summary)}</p>
                <span className="mt-5 text-sm font-medium text-navy-800 underline decoration-navy-300 underline-offset-4 group-hover:decoration-teal-700">{t('cta.readCase')}</span>
              </Link>
            </li>
          ))}
        </ul>
      </div>
    </>
  );
}
