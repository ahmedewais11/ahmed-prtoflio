import { createContext, useContext, useEffect, type ReactNode } from 'react';
import type { Bilingual, Lang } from './types';
import { ui, type UiKey } from '../content/ui';

type Ctx = {
  lang: Lang;
  dir: 'ltr' | 'rtl';
  /** Pick the right language from a { en, ar } object. */
  tr: (text: Bilingual) => string;
  /** Look up an interface label from content/ui.ts. */
  t: (key: UiKey) => string;
  /** Build a link that stays in the current language, e.g. path('/about') -> '/ar/about'. */
  path: (to: string) => string;
};

const LanguageContext = createContext<Ctx | null>(null);

export function LanguageProvider({ lang, children }: { lang: Lang; children: ReactNode }) {
  const dir = lang === 'ar' ? 'rtl' : 'ltr';

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = dir;
    try {
      localStorage.setItem('lang', lang);
    } catch {
      /* storage unavailable: language still comes from the address */
    }
  }, [lang, dir]);

  const value: Ctx = {
    lang,
    dir,
    tr: (text) => text[lang],
    t: (key) => ui[key][lang],
    path: (to) => `/${lang}${to === '/' ? '' : to}`,
  };
  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
}

export function useLang() {
  const ctx = useContext(LanguageContext);
  if (!ctx) throw new Error('useLang must be used inside LanguageProvider');
  return ctx;
}

export function preferredLang(): Lang {
  try {
    const saved = localStorage.getItem('lang');
    if (saved === 'en' || saved === 'ar') return saved;
  } catch {
    /* ignore */
  }
  return navigator.language?.toLowerCase().startsWith('ar') ? 'ar' : 'en';
}
