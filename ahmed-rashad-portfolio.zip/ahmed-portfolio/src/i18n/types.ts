export type Lang = 'en' | 'ar';
export const LANGS: Lang[] = ['en', 'ar'];
/** A piece of text written in both languages. */
export type Bilingual = { en: string; ar: string };
