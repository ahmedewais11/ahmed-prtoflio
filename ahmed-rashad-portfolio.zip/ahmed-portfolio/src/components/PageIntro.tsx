import type { ReactNode } from 'react';

/** Title block at the top of each inner page. */
export function PageIntro({ title, lede, children }: { title: string; lede?: string; children?: ReactNode }) {
  return (
    <header className="border-b border-line bg-ivory">
      <div className="mx-auto max-w-6xl px-4 pb-12 pt-14 sm:px-6 sm:pt-20">
        <h1 className="max-w-3xl text-4xl font-semibold tracking-tight text-navy-900 sm:text-5xl">{title}</h1>
        {lede && <p className="mt-5 max-w-2xl text-lg leading-relaxed text-muted">{lede}</p>}
        {children}
      </div>
    </header>
  );
}

export function SectionTitle({ children, id, className = '' }: { children: ReactNode; id?: string; className?: string }) {
  return (
    <h2 id={id} className={`text-2xl font-semibold tracking-tight text-navy-900 sm:text-[1.75rem] ${className}`}>
      {children}
    </h2>
  );
}
