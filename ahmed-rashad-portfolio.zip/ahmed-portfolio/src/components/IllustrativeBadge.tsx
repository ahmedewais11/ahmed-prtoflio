import { useLang } from '../i18n/LanguageContext';

/** Small label that marks synthetic figures. Used on every chart and case-study metric. */
export function IllustrativeBadge({ className = '' }: { className?: string }) {
  const { t } = useLang();
  return (
    <span className={`inline-flex shrink-0 items-center gap-1.5 rounded-full border border-teal-700/30 bg-teal-100/60 px-2.5 py-0.5 text-xs font-medium text-teal-800 ${className}`}>
      <svg width="10" height="10" viewBox="0 0 10 10" aria-hidden="true">
        <circle cx="5" cy="5" r="4" fill="none" stroke="currentColor" strokeWidth="1.4" strokeDasharray="2 1.6" />
      </svg>
      {t('illustrative')}
    </span>
  );
}
