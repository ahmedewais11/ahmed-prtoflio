import { branchData, budgetData, investmentData } from '../content/caseStudies';

/** Small decorative thumbnail for each case study (the real charts are on the case study page). */
export function CasePreview({ slug }: { slug: string }) {
  const frame = 'block h-32 w-full rounded-md border border-line bg-white p-4';
  if (slug === 'branch-performance') {
    const max = 40;
    const rows = [
      { std: branchData.standardCostPct.a, act: branchData.actualCostPct.a },
      { std: branchData.standardCostPct.b, act: branchData.actualCostPct.b },
    ];
    return (
      <svg viewBox="0 0 200 96" className={frame} aria-hidden="true" preserveAspectRatio="none">
        {rows.map((r, i) => (
          <g key={i} transform={`translate(0,${12 + i * 44})`}>
            <rect width={(r.std / max) * 200} height="12" rx="1.5" fill="var(--color-navy-300)" />
            <rect y="16" width={(r.act / max) * 200} height="12" rx="1.5" fill={i ? 'var(--color-teal-700)' : 'var(--color-navy-800)'} />
          </g>
        ))}
      </svg>
    );
  }
  if (slug === 'budget-forecast') {
    const b = budgetData.revenueBudget;
    const a = budgetData.revenueActual;
    const fc = b.slice(6).map((v) => v * 0.98);
    const lo = 430;
    const hi = 670;
    const x = (i: number) => (i / 11) * 200;
    const y = (v: number) => 92 - ((v - lo) / (hi - lo)) * 88;
    const pts = (vals: number[], off = 0) => vals.map((v, i) => `${x(i + off)},${y(v)}`).join(' ');
    return (
      <svg viewBox="0 0 200 96" className={frame} aria-hidden="true" preserveAspectRatio="none">
        <polyline points={pts(b)} fill="none" stroke="var(--color-budget)" strokeWidth="1.5" vectorEffect="non-scaling-stroke" />
        <polyline points={pts(a)} fill="none" stroke="var(--color-navy-800)" strokeWidth="2.5" vectorEffect="non-scaling-stroke" />
        <polyline points={pts([a[5], ...fc], 5)} fill="none" stroke="var(--color-teal-700)" strokeWidth="2.5" strokeDasharray="5 4" vectorEffect="non-scaling-stroke" />
      </svg>
    );
  }
  // cash-flow-investment: cumulative cash position
  let cum = -investmentData.investment;
  const vals = [cum, ...investmentData.baseInflows.map((v) => (cum += v))];
  const min = -1600;
  const max = 1000;
  const y = (v: number) => 4 + ((max - v) / (max - min)) * 88;
  return (
    <svg viewBox="0 0 200 96" className={frame} aria-hidden="true" preserveAspectRatio="none">
      <line x1="0" x2="200" y1={y(0)} y2={y(0)} stroke="var(--color-navy-300)" strokeWidth="1" vectorEffect="non-scaling-stroke" />
      {vals.map((v, i) => (
        <rect key={i} x={i * 33 + 4} width="24" y={Math.min(y(v), y(0))} height={Math.abs(y(v) - y(0))} rx="1.5" fill={v < 0 ? 'var(--color-navy-300)' : 'var(--color-teal-700)'} />
      ))}
    </svg>
  );
}
