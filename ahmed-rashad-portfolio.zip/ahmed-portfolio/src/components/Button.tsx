import { Link } from 'react-router-dom';
import type { ReactNode } from 'react';

type Variant = 'primary' | 'secondary' | 'onDark' | 'text';

const styles: Record<Variant, string> = {
  primary: 'bg-navy-900 text-white hover:bg-navy-800 px-5 py-3',
  secondary: 'border border-navy-900/25 text-navy-900 hover:border-navy-900 hover:bg-white px-5 py-3',
  onDark: 'bg-white text-navy-900 hover:bg-ivory px-5 py-3',
  text: 'text-teal-800 underline decoration-teal-700/40 underline-offset-4 hover:decoration-teal-700',
};

type Props = { to?: string; href?: string; variant?: Variant; children: ReactNode; external?: boolean; className?: string; onClick?: () => void };

export function Button({ to, href, variant = 'primary', children, external, className = '', onClick }: Props) {
  const cls = `inline-flex items-center justify-center gap-2 rounded-md text-[0.95rem] font-medium transition-colors ${styles[variant]} ${className}`;
  if (to) return <Link to={to} className={cls}>{children}</Link>;
  if (href)
    return (
      <a href={href} className={cls} {...(external ? { target: '_blank', rel: 'noopener noreferrer' } : {})}>
        {children}
      </a>
    );
  return (
    <button type="button" onClick={onClick} className={cls}>
      {children}
    </button>
  );
}
