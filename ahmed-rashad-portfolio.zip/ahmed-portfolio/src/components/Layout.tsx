import { useEffect, useState } from 'react';
import { Link, NavLink, Outlet, useLocation } from 'react-router-dom';
import { useLang } from '../i18n/LanguageContext';
import { profile } from '../content/profile';
import type { UiKey } from '../content/ui';

const NAV: { to: string; key: UiKey }[] = [
  { to: '/', key: 'nav.home' },
  { to: '/about', key: 'nav.about' },
  { to: '/expertise', key: 'nav.expertise' },
  { to: '/portfolio', key: 'nav.portfolio' },
  { to: '/tools', key: 'nav.tools' },
  { to: '/contact', key: 'nav.contact' },
];

function Logo() {
  const { tr, path } = useLang();
  return (
    <Link to={path('/')} className="flex items-center gap-3" aria-label={tr(profile.name)}>
      <img src="/favicon.svg" alt="" width={34} height={34} className="rounded-md" />
      <span className="leading-tight">
        <span className="block text-[0.95rem] font-semibold text-navy-900">{tr(profile.name)}</span>
        <span className="block text-xs text-muted">{tr(profile.title)}</span>
      </span>
    </Link>
  );
}

/** Link to the same page in the other language. Form inputs and scroll position are kept. */
function LanguageSwitch({ className = '' }: { className?: string }) {
  const { lang, t } = useLang();
  const { pathname, search, hash } = useLocation();
  const other = lang === 'en' ? 'ar' : 'en';
  const to = pathname.replace(/^\/(en|ar)(?=\/|$)/, `/${other}`) + search + hash;
  return (
    <Link
      to={to}
      preventScrollReset
      lang={other}
      hrefLang={other}
      aria-label={t('lang.switchLabel')}
      className={`inline-flex items-center rounded-md border border-navy-900/20 px-3 py-1.5 text-sm font-medium text-navy-900 transition-colors hover:border-navy-900 hover:bg-white ${other === 'ar' ? 'font-[family-name:var(--font-arabic)]' : ''} ${className}`}
    >
      {t('lang.switch')}
    </Link>
  );
}

function Header() {
  const { t, path } = useLang();
  const [open, setOpen] = useState(false);
  const { pathname } = useLocation();
  useEffect(() => setOpen(false), [pathname]);

  const linkCls = ({ isActive }: { isActive: boolean }) =>
    `relative py-1 text-[0.92rem] transition-colors ${isActive ? 'text-navy-900 font-medium after:absolute after:inset-x-0 after:-bottom-[1.15rem] after:h-0.5 after:bg-teal-700' : 'text-muted hover:text-navy-900'}`;

  return (
    <header className="sticky top-0 z-30 border-b border-line bg-ivory/95 backdrop-blur supports-[backdrop-filter]:bg-ivory/85">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-4 px-4 sm:px-6">
        <Logo />
        <nav aria-label={t('nav.main')} className="hidden items-center gap-6 lg:flex">
          {NAV.map((n) => (
            <NavLink key={n.to} to={path(n.to)} end={n.to === '/'} className={linkCls}>
              {t(n.key)}
            </NavLink>
          ))}
          <LanguageSwitch />
        </nav>
        <div className="flex items-center gap-2 lg:hidden">
          <LanguageSwitch />
          <button
            type="button"
            onClick={() => setOpen((o) => !o)}
            aria-expanded={open}
            aria-controls="mobile-nav"
            aria-label={open ? t('nav.close') : t('nav.open')}
            className="grid h-9 w-9 place-items-center rounded-md text-navy-900 hover:bg-white"
          >
            <svg width="20" height="20" viewBox="0 0 20 20" aria-hidden="true">
              {open ? (
                <path d="M5 5l10 10M15 5L5 15" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
              ) : (
                <path d="M3 6h14M3 10h14M3 14h14" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
              )}
            </svg>
          </button>
        </div>
      </div>
      {open && (
        <nav id="mobile-nav" aria-label={t('nav.main')} className="border-t border-line bg-ivory px-4 pb-4 lg:hidden">
          <ul>
            {NAV.map((n) => (
              <li key={n.to}>
                <NavLink
                  to={path(n.to)}
                  end={n.to === '/'}
                  className={({ isActive }) => `block border-b border-line/70 py-3 text-base ${isActive ? 'font-medium text-teal-800' : 'text-navy-900'}`}
                >
                  {t(n.key)}
                </NavLink>
              </li>
            ))}
          </ul>
        </nav>
      )}
    </header>
  );
}

function Footer() {
  const { t, tr, path } = useLang();
  return (
    <footer className="bg-navy-950 text-navy-100">
      <div className="mx-auto grid max-w-6xl gap-8 px-4 py-12 sm:px-6 md:grid-cols-[1.4fr_1fr_1fr]">
        <div>
          <p className="font-semibold text-white">{tr(profile.name)}</p>
          <p className="mt-1 text-sm text-navy-300">{tr(profile.title)}</p>
          <p className="mt-4 max-w-sm text-sm text-navy-300">{tr(profile.brandStatement)}</p>
        </div>
        <nav aria-label={t('nav.main')}>
          <ul className="grid grid-cols-2 gap-x-4 gap-y-2 text-sm">
            {NAV.map((n) => (
              <li key={n.to}>
                <Link to={path(n.to)} className="text-navy-100 hover:text-white">
                  {t(n.key)}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
        <div className="text-sm">
          <a href={`mailto:${profile.email}`} className="block break-all text-navy-100 hover:text-white">
            {profile.email}
          </a>
          <a href={profile.linkedin} target="_blank" rel="noopener noreferrer" className="mt-2 block text-navy-100 hover:text-white">
            LinkedIn <span className="sr-only">{t('newTab')}</span>
          </a>
        </div>
      </div>
      <div className="border-t border-white/10">
        <p className="mx-auto max-w-6xl px-4 py-5 text-xs text-navy-300 sm:px-6">
          © {new Date().getFullYear()} {tr(profile.name)}. {t('footer.note')}
        </p>
      </div>
    </footer>
  );
}

/** Scroll to top when the page changes, but NOT when only the language changes. */
function ScrollManager() {
  const { pathname } = useLocation();
  const page = pathname.replace(/^\/(en|ar)/, '');
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [page]);
  return null;
}

export function Layout() {
  const { t } = useLang();
  return (
    <>
      <a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:start-3 focus:top-3 focus:z-50 focus:rounded-md focus:bg-navy-900 focus:px-4 focus:py-2 focus:text-white">
        {t('skip')}
      </a>
      <ScrollManager />
      <Header />
      <main id="main" tabIndex={-1} className="outline-none">
        <Outlet />
      </main>
      <Footer />
    </>
  );
}
