import { useLang } from '../../i18n/LanguageContext';
import { budgetData, months } from '../../content/caseStudies';
import { Figure } from '../charts/Figure';
import { BarChart } from '../charts/BarChart';
import { LineChart } from '../charts/LineChart';
import { fmtNum, fmtSigned, fmtSignedPct } from '../../lib/format';
import { sum } from '../../lib/finance';

export function scenarioOutlook() {
  const { revenueBudget: rb, revenueActual: ra, expenseBudget: eb, expenseActual: ea, scenarios } = budgetData;
  const budgetProfit = sum(rb) - sum(eb);
  return scenarios.map((s) => {
    const revenue = sum(ra) + s.revenueFactor * sum(rb.slice(6));
    const expenses = sum(ea) + s.expenseFactor * sum(eb.slice(6));
    const profit = revenue - expenses;
    return { ...s, revenue, expenses, profit, vsBudget: (profit / budgetProfit - 1) * 100 };
  });
}

export function BudgetAnalysis() {
  const { t, tr, lang } = useLang();
  const m = months[lang];
  const { revenueBudget: rb, revenueActual: ra, expenseBudget: eb, expenseActual: ea, scenarios } = budgetData;
  const k = (v: number) => fmtNum(v, lang);
  const ks = (v: number) => fmtSigned(v, lang);

  const fc = (f: number) => rb.slice(6).map((v) => Math.round(v * f));
  const base = scenarios.find((s) => s.key === 'base')!;
  const down = scenarios.find((s) => s.key === 'downside')!;
  const up = scenarios.find((s) => s.key === 'upside')!;

  const variance = ra.map((a, i) => {
    const rev = a - rb[i];
    const exp = ea[i] - eb[i];
    return { month: m[i], rev, exp, profit: rev - exp };
  });
  const tot = variance.reduce((s, v) => ({ rev: s.rev + v.rev, exp: s.exp + v.exp, profit: s.profit + v.profit }), { rev: 0, exp: 0, profit: 0 });
  const outlook = scenarioOutlook();
  const tone = (v: number) => (v > 0 ? 'text-teal-800' : v < 0 ? 'text-loss' : '');

  return (
    <div className="grid gap-6">
      <Figure
        title={t('c2.trend')}
        subtitle={t('unitK')}
        legend={[
          { name: t('c2.budget'), color: 'var(--color-budget)', kind: 'line' },
          { name: t('c2.actual'), color: 'var(--color-navy-800)', kind: 'line' },
          { name: t('c2.forecast'), color: 'var(--color-teal-700)', kind: 'dashed' },
          { name: `${tr(down.name)} – ${tr(up.name)}`, color: 'var(--color-teal-700)', kind: 'band' },
        ]}
        table={{
          headers: [t('c2.month'), t('c2.budget'), t('c2.actual'), t('c2.forecast')],
          rows: m.map((mm, i) => [mm, k(rb[i]), i < 6 ? k(ra[i]) : '–', i >= 6 ? k(Math.round(rb[i] * base.revenueFactor)) : '–']),
        }}
      >
        <LineChart
          ariaLabel={t('c2.trend')}
          categories={m}
          height={280}
          format={k}
          divider={{ index: 6, label: t('c2.forecast') }}
          band={{ lower: [...Array(5).fill(null), ra[5], ...fc(down.revenueFactor)], upper: [...Array(5).fill(null), ra[5], ...fc(up.revenueFactor)], color: 'var(--color-teal-700)' }}
          series={[
            { name: t('c2.budget'), values: rb, color: 'var(--color-budget)', muted: true },
            { name: t('c2.actual'), values: ra, color: 'var(--color-navy-800)' },
            { name: t('c2.forecast'), values: [...Array(5).fill(null), ra[5], ...fc(base.revenueFactor)].slice(0, 12), color: 'var(--color-teal-700)', dashed: true },
          ]}
        />
      </Figure>

      <div className="grid gap-6 lg:grid-cols-[1fr_1.1fr]">
        <Figure title={t('c2.profitVar')} subtitle={`${t('c2.variance')}, ${t('unitK')}`} note={t('c2.varNote')}>
          <BarChart
            ariaLabel={t('c2.variance')}
            categories={variance.map((v) => v.month)}
            series={[{ name: t('c2.profitVar'), values: variance.map((v) => v.profit), color: 'var(--color-navy-800)' }]}
            signColors={{ pos: 'var(--color-teal-700)', neg: 'var(--color-loss)' }}
            format={ks}
            valueLabels
            height={230}
          />
        </Figure>

        <Figure title={t('c2.variance')} subtitle={t('unitK')}>
          <div className="overflow-x-auto">
            <table className="w-full text-sm tabular-nums">
              <thead>
                <tr className="border-b border-line text-muted">
                  <th scope="col" className="py-2 pe-3 text-start font-medium">{t('c2.month')}</th>
                  <th scope="col" className="px-2 py-2 text-end font-medium">{t('c2.revVar')}</th>
                  <th scope="col" className="px-2 py-2 text-end font-medium">{t('c2.expVar')}</th>
                  <th scope="col" className="ps-2 py-2 text-end font-medium">{t('c2.profitVar')}</th>
                </tr>
              </thead>
              <tbody>
                {variance.map((v) => (
                  <tr key={v.month} className="border-b border-line/60">
                    <th scope="row" className="py-2 pe-3 text-start font-normal">{v.month}</th>
                    <td className={`px-2 py-2 text-end ${tone(v.rev)}`}>{ks(v.rev)}</td>
                    <td className={`px-2 py-2 text-end ${tone(-v.exp)}`}>{ks(v.exp)}</td>
                    <td className={`ps-2 py-2 text-end font-medium ${tone(v.profit)}`}>{ks(v.profit)}</td>
                  </tr>
                ))}
                <tr className="border-t-2 border-navy-900/70 font-semibold">
                  <th scope="row" className="py-2 pe-3 text-start">{t('c2.total')}</th>
                  <td className={`px-2 py-2 text-end ${tone(tot.rev)}`}>{ks(tot.rev)}</td>
                  <td className={`px-2 py-2 text-end ${tone(-tot.exp)}`}>{ks(tot.exp)}</td>
                  <td className={`ps-2 py-2 text-end ${tone(tot.profit)}`}>{ks(tot.profit)}</td>
                </tr>
              </tbody>
            </table>
          </div>
          <p className="mt-3 text-sm text-muted">
            {lang === 'ar' ? 'انحراف المصروفات الموجب يعني تجاوزًا للموازنة (غير مُواتٍ).' : 'A positive expense variance means spending above budget (unfavourable).'}
          </p>
        </Figure>
      </div>

      <Figure title={t('c2.scenarios')} subtitle={t('unitK')}>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[30rem] text-sm tabular-nums">
            <thead>
              <tr className="border-b border-line text-muted">
                <th scope="col" className="py-2 pe-3 text-start font-medium">{t('c2.scenario')}</th>
                <th scope="col" className="px-2 py-2 text-end font-medium">{t('c2.revenue')}</th>
                <th scope="col" className="px-2 py-2 text-end font-medium">{t('c2.expenses')}</th>
                <th scope="col" className="px-2 py-2 text-end font-medium">{t('c2.profit')}</th>
                <th scope="col" className="ps-2 py-2 text-end font-medium">{t('c2.vsBudget')}</th>
              </tr>
            </thead>
            <tbody>
              {outlook.map((o) => (
                <tr key={o.key} className={`border-b border-line/60 ${o.key === 'base' ? 'bg-teal-100/40 font-medium' : ''}`}>
                  <th scope="row" className="py-2.5 pe-3 ps-2 text-start font-[inherit]">{tr(o.name)}</th>
                  <td className="px-2 py-2.5 text-end">{k(o.revenue)}</td>
                  <td className="px-2 py-2.5 text-end">{k(o.expenses)}</td>
                  <td className="px-2 py-2.5 text-end">{k(o.profit)}</td>
                  <td className={`ps-2 pe-2 py-2.5 text-end ${tone(o.vsBudget)}`}>{fmtSignedPct(o.vsBudget, lang)}</td>
                </tr>
              ))}
              <tr className="text-muted">
                <th scope="row" className="py-2.5 pe-3 ps-2 text-start font-normal">{t('c2.budget')}</th>
                <td className="px-2 py-2.5 text-end">{k(sum(rb))}</td>
                <td className="px-2 py-2.5 text-end">{k(sum(eb))}</td>
                <td className="px-2 py-2.5 text-end">{k(sum(rb) - sum(eb))}</td>
                <td className="ps-2 pe-2 py-2.5 text-end">–</td>
              </tr>
            </tbody>
          </table>
        </div>
        <p className="mt-3 text-sm text-muted">
          {lang === 'ar'
            ? 'السيناريوهات تطبق نسبة على موازنة يوليو–ديسمبر: الإيرادات 93% / 98% / 103%، والمصروفات 98% / 100% / 101%. الفعلي للنصف الأول ثابت.'
            : 'Scenarios apply a factor to the July–December budget: revenue at 93% / 98% / 103% and expenses at 98% / 100% / 101%. H1 actuals are fixed.'}
        </p>
      </Figure>
    </div>
  );
}
