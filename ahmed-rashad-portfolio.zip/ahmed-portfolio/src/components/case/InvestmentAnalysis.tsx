import { useState } from 'react';
import { useLang } from '../../i18n/LanguageContext';
import { investmentData } from '../../content/caseStudies';
import { Figure } from '../charts/Figure';
import { BarChart } from '../charts/BarChart';
import { KpiCard } from '../KpiCard';
import { IllustrativeBadge } from '../IllustrativeBadge';
import { irr, npv, payback } from '../../lib/finance';
import { fmtK, fmtNum, fmtRatio, fmtSignedPct, fmtYears } from '../../lib/format';

function metrics(factor: number, rate = investmentData.hurdleRate) {
  const flows = [-investmentData.investment, ...investmentData.baseInflows.map((v) => v * factor)];
  return { flows, npv: npv(rate, flows), irr: irr(flows), payback: payback(flows), discPayback: payback(flows, rate) };
}

const RATES = [0.1, 0.12, 0.14, 0.16];
const CHANGES = [-0.2, -0.1, 0, 0.1, 0.2];

export function InvestmentAnalysis() {
  const { t, tr, lang } = useLang();
  const [key, setKey] = useState('base');
  const scen = investmentData.scenarios.find((s) => s.key === key)!;
  const r = metrics(scen.factor);
  const years = [t('c3.y0'), ...[1, 2, 3, 4, 5].map((y) => (lang === 'ar' ? `السنة ${y}` : `Y${y}`))];
  let c = 0;
  const cumulative = r.flows.map((v) => (c += v));
  const k = (v: number) => fmtNum(v, lang);
  const yrs = (v: number | null) => (v === null ? t('c3.notRecovered') : fmtYears(v, lang));

  return (
    <div className="grid gap-6">
      {/* Scenario switch */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div role="radiogroup" aria-label={t('c3.select')} className="inline-flex rounded-md border border-line bg-white p-1">
          {investmentData.scenarios.map((s) => (
            <button
              key={s.key}
              type="button"
              role="radio"
              aria-checked={s.key === key}
              onClick={() => setKey(s.key)}
              className={`rounded px-4 py-2 text-sm font-medium transition-colors ${s.key === key ? 'bg-navy-900 text-white' : 'text-navy-800 hover:bg-ivory'}`}
            >
              {tr(s.name)}
            </button>
          ))}
        </div>
        <p className="text-sm text-muted">{tr(scen.note)}</p>
      </div>

      <div className="rounded-lg border border-line bg-white p-5 sm:p-6">
        <div className="mb-5 flex justify-end">
          <IllustrativeBadge />
        </div>
        <div className="grid grid-cols-2 gap-x-6 gap-y-6 md:grid-cols-4" aria-live="polite">
          <KpiCard label={t('c3.npv')} value={fmtK(Math.round(r.npv), lang)} tone={r.npv >= 0 ? 'positive' : 'negative'} />
          <KpiCard label={t('c3.irr')} value={r.irr === null ? '–' : fmtRatio(r.irr, lang)} note={t('c3.hurdle')} tone={r.irr !== null && r.irr >= investmentData.hurdleRate ? 'positive' : 'negative'} />
          <KpiCard label={t('c3.payback')} value={yrs(r.payback)} />
          <KpiCard label={t('c3.discPayback')} value={yrs(r.discPayback)} tone={r.discPayback === null ? 'negative' : 'neutral'} />
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-[1.25fr_1fr]">
        <Figure
          title={t('c3.cash')}
          subtitle={`${tr(scen.name)}, ${t('unitK')}`}
          legend={[
            { name: t('c3.annual'), color: 'var(--color-navy-300)' },
            { name: t('c3.cumulative'), color: 'var(--color-teal-700)', kind: 'line' },
          ]}
          table={{ headers: [t('c3.year'), t('c3.annual'), t('c3.cumulative')], rows: years.map((y, i) => [y, k(r.flows[i]), k(cumulative[i])]) }}
        >
          <BarChart
            ariaLabel={t('c3.cash')}
            categories={years}
            series={[{ name: t('c3.annual'), values: r.flows, color: 'var(--color-navy-300)' }]}
            line={{ name: t('c3.cumulative'), values: cumulative, color: 'var(--color-teal-700)' }}
            format={k}
            domain={[-1600, 1000]}
          />
        </Figure>

        <Figure title={t('c3.compare')} subtitle={t('unitK')}>
          <div className="overflow-x-auto">
            <table className="w-full text-sm tabular-nums">
              <thead>
                <tr className="border-b border-line text-muted">
                  <th scope="col" className="py-2 pe-2 text-start font-medium" />
                  {investmentData.scenarios.map((s) => (
                    <th key={s.key} scope="col" className={`px-2 py-2 text-end font-medium ${s.key === key ? 'text-navy-900' : ''}`}>
                      {tr(s.name)}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {(
                  [
                    [t('c3.npv'), (m: ReturnType<typeof metrics>) => k(m.npv)],
                    [t('c3.irr'), (m: ReturnType<typeof metrics>) => (m.irr === null ? '–' : fmtRatio(m.irr, lang))],
                    [t('c3.payback'), (m: ReturnType<typeof metrics>) => (m.payback === null ? '–' : fmtNum(m.payback, lang, 1, 1))],
                    [t('c3.discPayback'), (m: ReturnType<typeof metrics>) => (m.discPayback === null ? '>5' : fmtNum(m.discPayback, lang, 1, 1))],
                    [t('c3.decision'), (m: ReturnType<typeof metrics>) => (m.npv >= 0 ? t('yes') : t('no'))],
                  ] as const
                ).map(([label, fn]) => (
                  <tr key={label} className="border-b border-line/60 last:border-0">
                    <th scope="row" className="py-2.5 pe-2 text-start font-normal text-muted">{label}</th>
                    {investmentData.scenarios.map((s) => {
                      const m = metrics(s.factor);
                      return (
                        <td key={s.key} className={`px-2 py-2.5 text-end ${s.key === key ? 'bg-teal-100/40 font-medium text-navy-900' : ''} ${m.npv < 0 ? 'text-loss' : ''}`}>
                          {fn(m)}
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="mt-3 text-sm text-muted">{lang === 'ar' ? 'فترات الاسترداد بالسنوات.' : 'Payback periods in years.'}</p>
        </Figure>
      </div>

      <Figure title={t('c3.sensitivity')} subtitle={`${t('unitK')}. ${t('c3.sensitivity.note')}`}>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[28rem] text-sm tabular-nums">
            <thead>
              <tr className="text-muted">
                <th scope="col" className="py-2 pe-3 text-start font-medium">{t('c3.rate')}</th>
                {CHANGES.map((ch) => (
                  <th key={ch} scope="col" className="px-2 py-2 text-end font-medium">
                    {ch === 0 ? tr({ en: 'Base', ar: 'أساسي' }) : fmtSignedPct(ch * 100, lang, 0)}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {RATES.map((rate) => (
                <tr key={rate} className="border-t border-line/60">
                  <th scope="row" className="py-2 pe-3 text-start font-normal">{fmtRatio(rate, lang, 0)}</th>
                  {CHANGES.map((ch) => {
                    const v = metrics(1 + ch, rate).npv;
                    const isBase = rate === investmentData.hurdleRate && ch === 0;
                    return (
                      <td key={ch} className="px-1 py-1 text-end">
                        <span className={`block rounded px-2 py-1.5 ${v >= 0 ? 'bg-teal-100/70 text-teal-800' : 'bg-loss-100 text-loss'} ${isBase ? 'font-semibold ring-2 ring-navy-900' : ''}`}>
                          {k(v)}
                        </span>
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Figure>
    </div>
  );
}
