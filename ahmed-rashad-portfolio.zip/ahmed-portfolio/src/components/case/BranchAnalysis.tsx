import { useLang } from '../../i18n/LanguageContext';
import { branchData, months } from '../../content/caseStudies';
import { Figure } from '../charts/Figure';
import { BarChart } from '../charts/BarChart';
import { Waterfall } from '../charts/Waterfall';
import { fmtNum, fmtSigned } from '../../lib/format';

const A = 'var(--color-navy-800)';
const B = 'var(--color-teal-700)';

export function BranchAnalysis() {
  const { t, tr, lang } = useLang();
  const m = months[lang].slice(0, 6);
  const [nameA, nameB] = branchData.branches.map(tr);
  const pct = (v: number) => `${fmtNum(v, lang, 1, 1)}%`;
  const pctAxis = (v: number) => `${fmtNum(v, lang)}%`;
  const k = (v: number) => fmtNum(v, lang);

  const { standardCostPct: std, actualCostPct: act } = branchData;
  const pp = (v: number, signed = false) => (signed ? fmtSigned(v, lang, 1, 1) : `${fmtNum(v, lang, 1, 1)}%`);

  return (
    <div className="grid gap-6 lg:grid-cols-2">
      <Figure
        title={t('c1.revenue')}
        subtitle={t('unitK')}
        legend={[
          { name: nameA, color: A },
          { name: nameB, color: B },
        ]}
        table={{
          headers: [t('c2.month'), nameA, nameB],
          rows: m.map((mm, i) => [mm, k(branchData.revenue.a[i]), k(branchData.revenue.b[i])]),
        }}
      >
        <BarChart
          ariaLabel={t('c1.revenue')}
          categories={m}
          series={[
            { name: nameA, values: branchData.revenue.a, color: A },
            { name: nameB, values: branchData.revenue.b, color: B },
          ]}
          format={k}
        />
      </Figure>

      <Figure
        title={t('c1.cost')}
        legend={[
          { name: t('c1.standard'), color: 'var(--color-navy-300)' },
          { name: t('c1.actual'), color: 'var(--color-loss)' },
        ]}
      >
        <BarChart
          ariaLabel={t('c1.cost')}
          categories={[nameA, nameB]}
          series={[
            { name: t('c1.standard'), values: [std.a, std.b], color: 'var(--color-navy-300)' },
            { name: t('c1.actual'), values: [act.a, act.b], color: 'var(--color-loss)' },
          ]}
          format={pct}
          axisFormat={pctAxis}
          valueLabels
          domain={[0, 40]}
        />
      </Figure>

      <Figure
        title={t('c1.bridge')}
        subtitle={lang === 'ar' ? 'تكلفة المبيعات كنسبة من المبيعات. المحور لا يبدأ من الصفر لإظهار الفروق.' : 'Cost of sales as % of sales. Axis starts at 28% to make the steps visible.'}
      >
        <Waterfall
          domain={[28, 38]}
          ticks={[28, 30, 32, 34, 36, 38]}
          format={pp}
          tickFormat={pctAxis}
          colors={{ total: 'var(--color-navy-800)', up: 'var(--color-loss)', down: 'var(--color-teal-700)' }}
          steps={[
            { label: t('c1.bridge.a'), value: act.a, type: 'total' },
            { label: t('c1.bridge.exA'), value: -(act.a - std.a), type: 'delta' },
            { label: t('c1.bridge.mix'), value: +(std.b - std.a).toFixed(1), type: 'delta' },
            { label: t('c1.bridge.exB'), value: +(act.b - std.b).toFixed(1), type: 'delta' },
            { label: t('c1.bridge.b'), value: act.b, type: 'total' },
          ]}
        />
      </Figure>

      <Figure
        title={t('c1.mix')}
        legend={[
          { name: nameA, color: A },
          { name: nameB, color: B },
        ]}
        table={{
          headers: [t('c1.category'), t('c1.stdCost'), nameA, nameB],
          rows: branchData.categories.map((c) => [tr(c.name), pctAxis(c.standardCostPct), pctAxis(c.mixA), pctAxis(c.mixB)]),
        }}
      >
        <BarChart
          ariaLabel={t('c1.mix')}
          categories={branchData.categories.map((c) => `${tr(c.name)} (${c.standardCostPct}%)`)}
          series={[
            { name: nameA, values: branchData.categories.map((c) => c.mixA), color: A },
            { name: nameB, values: branchData.categories.map((c) => c.mixB), color: B },
          ]}
          format={pctAxis}
          valueLabels
        />
      </Figure>
    </div>
  );
}
