import { useId, useMemo, useState } from 'react';
import { useLang } from '../i18n/LanguageContext';
import { breakEven } from '../lib/finance';
import { fmtMoney, fmtNum, fmtRatio } from '../lib/format';
import { KpiCard } from './KpiCard';
import { LineChart } from './charts/LineChart';
import type { UiKey } from '../content/ui';

const CURRENCIES = ['SAR', 'USD', 'EGP', 'AED', 'EUR'];
const MAX = 1e12;

type Field = 'price' | 'variable' | 'fixed' | 'current';
type Values = Record<Field, string>;
const EMPTY: Values = { price: '', variable: '', fixed: '', current: '' };
const EXAMPLE: Values = { price: '50', variable: '30', fixed: '100000', current: '7000' };

/** Accepts "1,250.5", " 1250 ", and Arabic-Indic digits like "١٢٥٠". */
function parse(raw: string): number | null {
  const s = raw
    .trim()
    .replace(/[٠-٩]/g, (d) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)))
    .replace(/٫/g, '.')
    .replace(/[,٬\s]/g, '');
  if (s === '') return null;
  if (!/^-?(\d+\.?\d*|\.\d+)$/.test(s)) return NaN;
  return Number(s);
}

function validate(field: Field, raw: string): { value?: number; error?: UiKey } {
  const v = parse(raw);
  if (v === null) return field === 'current' ? {} : { error: 'err.required' };
  if (Number.isNaN(v)) return { error: 'err.number' };
  if (v < 0) return { error: 'err.negative' };
  if (Math.abs(v) > MAX) return { error: 'err.tooLarge' };
  if (field === 'price' && v === 0) return { error: 'err.pricePositive' };
  return { value: v };
}

export function BreakEvenCalculator() {
  const { t, lang } = useLang();
  const uid = useId();
  const [values, setValues] = useState<Values>(EMPTY);
  const [touched, setTouched] = useState<Record<Field, boolean>>({ price: false, variable: false, fixed: false, current: false });
  const [currency, setCurrency] = useState('SAR');

  const checks = useMemo(
    () => ({
      price: validate('price', values.price),
      variable: validate('variable', values.variable),
      fixed: validate('fixed', values.fixed),
      current: validate('current', values.current),
    }),
    [values],
  );

  const ready = !checks.price.error && !checks.variable.error && !checks.fixed.error && !checks.current.error;
  const result = ready
    ? breakEven({ price: checks.price.value!, variableCost: checks.variable.value!, fixedCosts: checks.fixed.value!, currentUnits: checks.current.value })
    : null;

  const money = (n: number) => fmtMoney(n, lang, currency);
  const units = (n: number) => `${fmtNum(n, lang, 0)} ${t('tools.units')}`;

  const set = (f: Field) => (e: React.ChangeEvent<HTMLInputElement>) => setValues((v) => ({ ...v, [f]: e.target.value }));
  const blur = (f: Field) => () => setTouched((tt) => ({ ...tt, [f]: true }));
  const anyInput = Object.values(values).some((v) => v.trim() !== '');

  const field = (f: Field, label: UiKey, opts: { hint?: UiKey; optional?: boolean; money?: boolean } = {}) => {
    const err = touched[f] || (anyInput && values[f] !== '') ? checks[f].error : undefined;
    const id = `${uid}-${f}`;
    return (
      <div>
        <label htmlFor={id} className="flex items-baseline justify-between gap-2 text-sm font-medium text-navy-900">
          {t(label)}
          {opts.optional && <span className="text-xs font-normal text-muted">{t('tools.optional')}</span>}
        </label>
        <div className={`mt-1.5 flex items-stretch overflow-hidden rounded-md border bg-white focus-within:ring-2 focus-within:ring-teal-700/40 ${err ? 'border-loss' : 'border-navy-300/70 focus-within:border-teal-700'}`}>
          {opts.money && <span className="grid place-items-center border-e border-line bg-ivory px-3 text-sm text-muted" dir="ltr">{currency}</span>}
          <input
            id={id}
            inputMode="decimal"
            autoComplete="off"
            dir="ltr"
            value={values[f]}
            onChange={set(f)}
            onBlur={blur(f)}
            aria-invalid={!!err}
            aria-describedby={err ? `${id}-err` : opts.hint ? `${id}-hint` : undefined}
            className="w-full min-w-0 bg-transparent px-3 py-2.5 text-base tabular-nums text-ink outline-none rtl:text-right"
            placeholder="0"
          />
        </div>
        {err ? (
          <p id={`${id}-err`} role="alert" className="mt-1.5 text-sm text-loss">
            {t(err)}
          </p>
        ) : (
          opts.hint && (
            <p id={`${id}-hint`} className="mt-1.5 text-xs text-muted">
              {t(opts.hint)}
            </p>
          )
        )}
      </div>
    );
  };

  return (
    <div className="grid gap-6 lg:grid-cols-[22rem_1fr] lg:items-start">
      {/* ----- Inputs ----- */}
      <form className="rounded-lg border border-line bg-white p-5 sm:p-6 lg:sticky lg:top-24" onSubmit={(e) => e.preventDefault()} noValidate>
        <div className="flex items-center justify-between gap-3">
          <h2 className="text-lg font-semibold text-navy-900">{t('tools.inputs')}</h2>
          <label className="flex items-center gap-2 text-sm text-muted">
            {t('tools.currency')}
            <select value={currency} onChange={(e) => setCurrency(e.target.value)} className="rounded-md border border-navy-300/70 bg-white px-2 py-1 text-sm text-navy-900" dir="ltr">
              {CURRENCIES.map((c) => (
                <option key={c}>{c}</option>
              ))}
            </select>
          </label>
        </div>
        <div className="mt-5 grid gap-5">
          {field('price', 'tools.price', { money: true })}
          {field('variable', 'tools.variable', { money: true })}
          {field('fixed', 'tools.fixed', { money: true, hint: 'tools.fixed.hint' })}
          {field('current', 'tools.current', { optional: true })}
        </div>
        <div className="mt-6 flex flex-wrap gap-3">
          <button type="button" onClick={() => setValues(EXAMPLE)} className="rounded-md bg-navy-900 px-4 py-2 text-sm font-medium text-white hover:bg-navy-800">
            {t('tools.example')}
          </button>
          <button
            type="button"
            onClick={() => {
              setValues(EMPTY);
              setTouched({ price: false, variable: false, fixed: false, current: false });
            }}
            className="rounded-md border border-navy-900/25 px-4 py-2 text-sm font-medium text-navy-900 hover:border-navy-900"
          >
            {t('tools.clear')}
          </button>
        </div>
      </form>

      {/* ----- Results ----- */}
      <section aria-labelledby={`${uid}-results`} aria-live="polite" className="grid gap-6">
        <h2 id={`${uid}-results`} className="sr-only">
          {t('tools.results')}
        </h2>

        {!result && (
          <div className="rounded-lg border border-dashed border-navy-300 bg-white/60 p-8 text-center text-muted">{t('tools.empty')}</div>
        )}

        {result && !result.ok && (
          <div role="alert" className="rounded-lg border border-loss/40 bg-loss-100 p-6">
            <p className="font-semibold text-loss">
              {t('tools.cm')}: {money(result.contributionMargin)}
            </p>
            <p className="mt-2 leading-relaxed text-ink">{t(result.contributionMargin === 0 ? 'err.margin.zero' : 'err.margin.negative')}</p>
          </div>
        )}

        {result && result.ok && (
          <>
            <div className="rounded-lg border border-line bg-white p-5 sm:p-6">
              <div className="grid gap-x-8 gap-y-7 sm:grid-cols-2 xl:grid-cols-3">
                <KpiCard label={t('tools.cm')} value={money(result.contributionMargin)} note={t('tools.cm.hint')} />
                <KpiCard label={t('tools.cmr')} value={fmtRatio(result.contributionMarginRatio, lang)} note={t('tools.cmr.hint')} />
                <KpiCard label={t('tools.beUnits')} value={units(result.breakEvenUnitsRounded)} note={t('tools.beUnits.hint')} />
                <KpiCard label={t('tools.beRevenue')} value={money(result.breakEvenRevenue)} note={t('tools.beRevenue.hint')} />
                {result.current ? (
                  <>
                    <KpiCard
                      label={t('tools.mos')}
                      value={money(result.current.marginOfSafetyRevenue)}
                      note={`${units(result.current.marginOfSafetyUnits)} · ${fmtRatio(result.current.marginOfSafetyRatio, lang)} ${t('tools.ofSales')}`}
                      tone={result.current.marginOfSafetyRevenue >= 0 ? 'positive' : 'negative'}
                    />
                    <KpiCard label={t('tools.profit')} value={money(result.current.profit)} tone={result.current.profit >= 0 ? 'positive' : 'negative'} />
                  </>
                ) : (
                  <KpiCard label={t('tools.mos')} value="–" note={t('tools.mos.none')} />
                )}
              </div>
            </div>

            <ComparisonChart
              be={result.breakEvenRevenue}
              current={result.current?.revenue}
              money={money}
            />

            <CvpChart price={checks.price.value!} variable={checks.variable.value!} fixed={checks.fixed.value!} beUnits={result.breakEvenUnits} current={result.current?.units} money={money} />
          </>
        )}

        <details className="rounded-lg border border-line bg-white p-5 text-sm">
          <summary className="cursor-pointer font-medium text-navy-900">{t('tools.method')}</summary>
          <p className="mt-3 leading-relaxed text-muted">{t('tools.method.body')}</p>
        </details>
      </section>
    </div>
  );
}

/** Horizontal bars: break-even sales vs current sales. Built in HTML so it mirrors correctly in Arabic. */
function ComparisonChart({ be, current, money }: { be: number; current?: number; money: (n: number) => string }) {
  const { t } = useLang();
  const max = Math.max(be, current ?? 0) * 1.08 || 1;
  const status = current === undefined ? null : Math.abs(current - be) < 1e-6 ? 'at' : current > be ? 'above' : 'below';
  const bar = (label: string, value: number, color: string) => (
    <div>
      <div className="flex items-baseline justify-between gap-3 text-sm">
        <span className="text-muted">{label}</span>
        <span className="font-semibold tabular-nums text-navy-900">{money(value)}</span>
      </div>
      <div className="relative mt-1.5 h-7 rounded-[3px] bg-ivory">
        <span className="chart-bar absolute inset-y-0 start-0 rounded-[3px]" style={{ width: `${(value / max) * 100}%`, background: color }} />
        <span aria-hidden="true" className="absolute -inset-y-1 w-0.5 bg-navy-900" style={{ insetInlineStart: `${(be / max) * 100}%` }} />
      </div>
    </div>
  );
  return (
    <figure className="rounded-lg border border-line bg-white p-5 sm:p-6">
      <figcaption className="font-semibold text-navy-900">{t('tools.chart')}</figcaption>
      <div className="mt-5 grid gap-5" role="img" aria-label={`${t('tools.chart.be')}: ${money(be)}${current !== undefined ? `; ${t('tools.chart.current')}: ${money(current)}` : ''}`}>
        {bar(t('tools.chart.be'), be, 'var(--color-navy-300)')}
        {current !== undefined
          ? bar(t('tools.chart.current'), current, status === 'below' ? 'var(--color-loss)' : 'var(--color-teal-700)')
          : <p className="text-sm text-muted">{t('tools.chart.noCurrent')}</p>}
      </div>
      {status && (
        <p className={`mt-4 text-sm font-medium ${status === 'below' ? 'text-loss' : 'text-teal-800'}`}>{t(`tools.status.${status}` as UiKey)}</p>
      )}
    </figure>
  );
}

/** Cost-volume-profit chart: revenue and total cost lines cross at the break-even point. */
function CvpChart({ price, variable, fixed, beUnits, current, money }: { price: number; variable: number; fixed: number; beUnits: number; current?: number; money: (n: number) => string }) {
  const { t, lang } = useLang();
  const top = Math.max(beUnits * 2, (current ?? 0) * 1.25, 1);
  const n = 8;
  const xs = Array.from({ length: n + 1 }, (_, i) => (top / n) * i);
  const compact = (v: number) => new Intl.NumberFormat(lang === 'ar' ? 'ar-SA-u-nu-latn' : 'en-US', { notation: 'compact', maximumFractionDigits: 1 }).format(v);
  return (
    <figure className="rounded-lg border border-line bg-white p-5 sm:p-6">
      <figcaption className="font-semibold text-navy-900">{t('tools.cvp')}</figcaption>
      <p className="mt-0.5 text-sm text-muted">{t('tools.cvp.note')}</p>
      <ul className="mb-3 mt-3 flex flex-wrap gap-x-5 text-sm text-muted">
        <li className="flex items-center gap-2"><span className="h-0.5 w-4 bg-teal-700" aria-hidden="true" />{t('tools.cvp.revenue')}</li>
        <li className="flex items-center gap-2"><span className="h-0.5 w-4 bg-navy-800" aria-hidden="true" />{t('tools.cvp.cost')}</li>
        <li className="flex items-center gap-2"><span className="h-0.5 w-4 bg-budget" aria-hidden="true" />{t('tools.cvp.fixed')}</li>
      </ul>
      <LineChart
        ariaLabel={`${t('tools.cvp')}. ${t('tools.beUnits')}: ${fmtNum(beUnits, lang, 0)}; ${t('tools.beRevenue')}: ${money(beUnits * price)}`}
        categories={xs.map((x) => compact(x))}
        height={240}
        format={compact}
        series={[
          { name: t('tools.cvp.fixed'), values: xs.map(() => fixed), color: 'var(--color-budget)', muted: true },
          { name: t('tools.cvp.cost'), values: xs.map((x) => fixed + variable * x), color: 'var(--color-navy-800)' },
          { name: t('tools.cvp.revenue'), values: xs.map((x) => price * x), color: 'var(--color-teal-700)' },
        ]}
        divider={{ index: (beUnits / top) * n + 0.5, label: t('tools.cvp.be') }}
      />
      <p className="mt-2 text-xs text-muted">{t('tools.cvp.axis')}</p>
    </figure>
  );
}
