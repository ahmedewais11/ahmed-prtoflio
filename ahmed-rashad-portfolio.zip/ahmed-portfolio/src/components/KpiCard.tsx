type Props = { label: string; value: string; note?: string; tone?: 'positive' | 'negative' | 'neutral' };

/** A single headline number with a label, used in case studies and the calculator. */
export function KpiCard({ label, value, note, tone = 'neutral' }: Props) {
  const color = tone === 'negative' ? 'text-loss' : tone === 'positive' ? 'text-teal-800' : 'text-navy-900';
  return (
    <div className="border-s-2 border-navy-900/15 ps-4">
      <p className="text-sm leading-snug text-muted">{label}</p>
      <p className={`mt-1.5 text-2xl font-semibold tabular-nums tracking-tight ${color}`}>{value}</p>
      {note && <p className="mt-1 text-sm text-muted">{note}</p>}
    </div>
  );
}
