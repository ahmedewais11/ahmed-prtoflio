import { niceTicks, linear } from '../../lib/scale';
import { useWidth } from '../../lib/useWidth';

export type LineSeries = { name: string; values: (number | null)[]; color: string; dashed?: boolean; muted?: boolean };

type Props = {
  categories: string[];
  series: LineSeries[];
  /** Shaded range, e.g. downside-to-upside forecast */
  band?: { lower: (number | null)[]; upper: (number | null)[]; color: string };
  format: (v: number) => string;
  height?: number;
  ariaLabel: string;
  /** Index where a vertical divider is drawn (e.g. "actuals | forecast") */
  divider?: { index: number; label?: string };
  compact?: boolean;
};

export function LineChart({ categories, series, band, format, height = 260, ariaLabel, divider, compact }: Props) {
  const [ref, width] = useWidth<HTMLDivElement>(320);
  const vals = [...series.flatMap((s) => s.values), ...(band ? [...band.lower, ...band.upper] : [])].filter((v): v is number => v !== null);
  const lo = Math.min(...vals);
  const hi = Math.max(...vals);
  const pad = (hi - lo) * 0.12;
  // Never invent a negative axis for data that is all zero or above
  const ticks = niceTicks(lo >= 0 ? Math.max(0, lo - pad) : lo - pad, hi + pad, compact ? 3 : 4);
  const m = compact ? { top: 6, right: 6, bottom: 6, left: 6 } : { top: 14, right: 12, bottom: 26, left: Math.max(...ticks.map((t) => format(t).length)) * 7 + 12 };
  const iw = Math.max(width - m.left - m.right, 50);
  const ih = height - m.top - m.bottom;
  const x = (i: number) => (categories.length === 1 ? iw / 2 : (i / (categories.length - 1)) * iw);
  const y = linear(ticks[0], ticks[ticks.length - 1], ih, 0);

  const path = (values: (number | null)[]) => {
    let d = '';
    let pen = false;
    values.forEach((v, i) => {
      if (v === null) {
        pen = false;
        return;
      }
      d += `${pen ? 'L' : 'M'}${x(i).toFixed(1)},${y(v).toFixed(1)}`;
      pen = true;
    });
    return d;
  };

  let bandPath = '';
  if (band) {
    const idx = band.upper.map((v, i) => (v !== null && band.lower[i] !== null ? i : -1)).filter((i) => i >= 0);
    if (idx.length) {
      bandPath =
        idx.map((i, k) => `${k ? 'L' : 'M'}${x(i)},${y(band.upper[i]!)}`).join('') +
        [...idx].reverse().map((i) => `L${x(i)},${y(band.lower[i]!)}`).join('') +
        'Z';
    }
  }
  const step = categories.length > 8 && iw < 480 ? 2 : 1;

  return (
    <div ref={ref} className="relative w-full" style={{ height }} dir="ltr">
      <svg width={width} height={height} role="img" aria-label={ariaLabel} className="absolute start-0 top-0 block overflow-visible text-[11.5px]">
        <g transform={`translate(${m.left},${m.top})`}>
          {!compact &&
            ticks.map((t) => (
              <g key={t} transform={`translate(0,${y(t)})`}>
                <line x2={iw} stroke="var(--color-line)" />
                <text x={-8} dy="0.32em" textAnchor="end" fill="var(--color-muted)">
                  {format(t)}
                </text>
              </g>
            ))}
          {divider && (
            <g transform={`translate(${(x(divider.index - 1) + x(divider.index)) / 2},0)`}>
              <line y1={0} y2={ih} stroke="var(--color-navy-300)" strokeDasharray="2 3" />
              {divider.label && !compact && (
                <text x={6} y={10} fill="var(--color-muted)">
                  {divider.label}
                </text>
              )}
            </g>
          )}
          {bandPath && <path d={bandPath} fill={band!.color} opacity={0.16} />}
          {series.map((s) => (
            <g key={s.name}>
              <path d={path(s.values)} fill="none" stroke={s.color} strokeWidth={s.muted ? 1.75 : 2.5} strokeDasharray={s.dashed ? '5 4' : undefined} strokeLinejoin="round" strokeLinecap="round" className="chart-line" />
              {!compact &&
                s.values.map((v, i) =>
                  v === null ? null : (
                    <circle key={i} cx={x(i)} cy={y(v)} r={s.muted ? 0 : 3} fill={s.dashed ? 'white' : s.color} stroke={s.color} strokeWidth={1.5}>
                      <title>{`${s.name} · ${categories[i]}: ${format(v)}`}</title>
                    </circle>
                  ),
                )}
            </g>
          ))}
          {!compact &&
            categories.map((c, i) =>
              i % step === 0 ? (
                <text key={c} x={x(i)} y={ih + 18} textAnchor="middle" fill="var(--color-muted)">
                  {c}
                </text>
              ) : null,
            )}
        </g>
      </svg>
    </div>
  );
}
