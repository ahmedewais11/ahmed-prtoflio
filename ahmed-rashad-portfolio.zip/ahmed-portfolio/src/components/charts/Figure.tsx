import type { ReactNode } from 'react';
import { useLang } from '../../i18n/LanguageContext';
import { IllustrativeBadge } from '../IllustrativeBadge';

export type LegendItem = { name: string; color: string; kind?: 'bar' | 'line' | 'dashed' | 'band' };

export function Legend({ items }: { items: LegendItem[] }) {
  return (
    <ul className="flex flex-wrap gap-x-5 gap-y-1.5 text-sm text-muted">
      {items.map((it) => (
        <li key={it.name} className="flex items-center gap-2">
          <Swatch {...it} />
          {it.name}
        </li>
      ))}
    </ul>
  );
}

function Swatch({ color, kind = 'bar' }: LegendItem) {
  if (kind === 'line' || kind === 'dashed')
    return (
      <svg width="18" height="8" aria-hidden="true">
        <line x1="0" y1="4" x2="18" y2="4" stroke={color} strokeWidth="2.5" strokeDasharray={kind === 'dashed' ? '4 3' : undefined} />
      </svg>
    );
  if (kind === 'band') return <span aria-hidden="true" className="inline-block h-2.5 w-4 rounded-[2px]" style={{ background: color, opacity: 0.25 }} />;
  return <span aria-hidden="true" className="inline-block h-2.5 w-2.5 rounded-[2px]" style={{ background: color }} />;
}

export type DataTable = { headers: string[]; rows: (string | number)[][] };

type Props = {
  title: string;
  subtitle?: string;
  legend?: LegendItem[];
  note?: string;
  table?: DataTable;
  children: ReactNode;
  illustrative?: boolean;
};

/** A titled chart panel with legend, optional note and an expandable data table. */
export function Figure({ title, subtitle, legend, note, table, children, illustrative = true }: Props) {
  const { lang } = useLang();
  return (
    <figure className="rounded-lg border border-line bg-white p-5 sm:p-6">
      <div className="mb-4 flex flex-wrap items-start justify-between gap-3">
        <div>
          <figcaption className="text-base font-semibold text-navy-900">{title}</figcaption>
          {subtitle && <p className="mt-0.5 text-sm text-muted">{subtitle}</p>}
        </div>
        {illustrative && <IllustrativeBadge />}
      </div>
      {legend && (
        <div className="mb-3">
          <Legend items={legend} />
        </div>
      )}
      {children}
      {note && <p className="mt-3 text-sm text-muted">{note}</p>}
      {table && (
        <details className="group mt-4 border-t border-line pt-3 text-sm">
          <summary className="cursor-pointer select-none text-navy-700 hover:text-teal-700">
            {lang === 'ar' ? 'عرض البيانات كجدول' : 'Show data as a table'}
          </summary>
          <div className="mt-3 overflow-x-auto">
            <table className="w-full min-w-max text-start tabular-nums">
              <thead>
                <tr className="border-b border-line text-muted">
                  {table.headers.map((h) => (
                    <th key={h} scope="col" className="py-1.5 pe-4 text-start font-medium">
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {table.rows.map((r, i) => (
                  <tr key={i} className="border-b border-line/60 last:border-0">
                    {r.map((c, j) => (
                      <td key={j} className="py-1.5 pe-4">
                        {c}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </details>
      )}
    </figure>
  );
}
