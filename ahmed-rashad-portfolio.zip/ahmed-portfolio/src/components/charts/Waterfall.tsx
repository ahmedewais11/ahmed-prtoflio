export type WaterfallStep = { label: string; value: number; type: 'total' | 'delta' };

type Props = {
  steps: WaterfallStep[];
  domain: [number, number];
  ticks: number[];
  format: (v: number, signed?: boolean) => string;
  tickFormat?: (v: number) => string;
  colors: { total: string; up: string; down: string };
};

/**
 * Horizontal bridge (waterfall) chart built with HTML so it mirrors naturally in Arabic.
 * Note: the axis does not start at zero, which is labelled by the tick values.
 */
export function Waterfall({ steps, domain, ticks, format, tickFormat = format, colors }: Props) {
  const [d0, d1] = domain;
  const pct = (v: number) => ((v - d0) / (d1 - d0)) * 100;
  let running = 0;
  const rows = steps.map((s) => {
    let from: number, to: number;
    if (s.type === 'total') {
      from = d0;
      to = s.value;
      running = s.value;
    } else {
      from = running;
      to = running + s.value;
      running = to;
    }
    return { ...s, start: Math.min(from, to), end: Math.max(from, to) };
  });

  return (
    <div className="text-sm">
      <div className="grid grid-cols-[minmax(7.5rem,11rem)_1fr_4rem] items-center gap-x-3">
        <span />
        <div className="relative h-5 text-xs text-muted">
          {ticks.map((t) => (
            <span key={t} className="absolute -translate-x-1/2 rtl:translate-x-1/2 tabular-nums" style={{ insetInlineStart: `${pct(t)}%` }}>
              {tickFormat(t)}
            </span>
          ))}
        </div>
        <span />
        {rows.map((r) => (
          <div key={r.label} className="contents">
            <span className={`py-2 leading-tight ${r.type === 'total' ? 'font-medium text-navy-900' : 'text-muted'}`}>{r.label}</span>
            <div className="relative h-7 border-s border-line">
              {ticks.map((t) => (
                <span key={t} aria-hidden="true" className="absolute inset-y-0 w-px bg-line/70" style={{ insetInlineStart: `${pct(t)}%` }} />
              ))}
              <span
                className="absolute inset-y-1 rounded-[2px] chart-bar"
                style={{
                  insetInlineStart: `${pct(r.start)}%`,
                  width: `${Math.max(pct(r.end) - pct(r.start), 0.6)}%`,
                  background: r.type === 'total' ? colors.total : r.value >= 0 ? colors.up : colors.down,
                }}
              />
            </div>
            <span className={`text-end tabular-nums ${r.type === 'total' ? 'font-semibold text-navy-900' : 'text-navy-800'}`}>
              {format(r.value, r.type === 'delta')}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
