import { niceTicks, linear } from '../../lib/scale';
import { useWidth } from '../../lib/useWidth';

export type BarSeries = { name: string; values: number[]; color: string };
export type LineOverlay = { name: string; values: number[]; color: string };

type Props = {
  categories: string[];
  series: BarSeries[];
  line?: LineOverlay;
  format: (v: number) => string;
  /** Short format for axis ticks (defaults to `format`). */
  axisFormat?: (v: number) => string;
  height?: number;
  valueLabels?: boolean;
  ariaLabel: string;
  /** Force the y-axis to include this range */
  domain?: [number, number];
  /** Colour bars by sign instead of series colour (variance charts). */
  signColors?: { pos: string; neg: string };
};

/**
 * Grouped vertical bar chart drawn in SVG. Supports negative values and an optional line overlay.
 * Charts always read left-to-right (time and categories), in both languages, as in most Arabic financial reports.
 */
export function BarChart({ categories, series, line, format, axisFormat = format, height = 260, valueLabels, ariaLabel, domain, signColors }: Props) {
  const [ref, width] = useWidth<HTMLDivElement>(320);
  const all = [...series.flatMap((s) => s.values), ...(line?.values ?? []), 0, ...(domain ?? [])];
  const ticks = niceTicks(Math.min(...all), Math.max(...all), height < 200 ? 3 : 5);
  const yMin = ticks[0];
  const yMax = ticks[ticks.length - 1];

  const m = { top: valueLabels ? 22 : 12, right: 8, bottom: 26, left: Math.max(...ticks.map((t) => axisFormat(t).length)) * 7 + 12 };
  const iw = Math.max(width - m.left - m.right, 50);
  const ih = height - m.top - m.bottom;
  const y = linear(yMin, yMax, ih, 0);
  const band = iw / categories.length;
  const groupPad = band * (series.length > 1 ? 0.22 : 0.3);
  const barW = (band - groupPad) / series.length;
  const narrow = band < 34;

  return (
    <div ref={ref} className="relative w-full" style={{ height }} dir="ltr">
      <svg width={width} height={height} role="img" aria-label={ariaLabel} className="absolute start-0 top-0 block overflow-visible text-[11.5px]">
        <g transform={`translate(${m.left},${m.top})`}>
          {ticks.map((t) => (
            <g key={t} transform={`translate(0,${y(t)})`}>
              <line x2={iw} stroke={t === 0 ? 'var(--color-navy-300)' : 'var(--color-line)'} />
              <text x={-8} dy="0.32em" textAnchor="end" fill="var(--color-muted)">
                {axisFormat(t)}
              </text>
            </g>
          ))}
          {categories.map((c, i) => (
            <g key={c} transform={`translate(${i * band},0)`}>
              {series.map((s, j) => {
                const v = s.values[i];
                const y0 = y(Math.max(0, v));
                const h = Math.abs(y(v) - y(0));
                const fill = signColors ? (v >= 0 ? signColors.pos : signColors.neg) : s.color;
                return (
                  <g key={s.name}>
                    <rect x={groupPad / 2 + j * barW + 1} y={y0} width={Math.max(barW - 2, 1)} height={Math.max(h, 0.5)} rx={1.5} fill={fill} className="chart-bar">
                      <title>{`${s.name} · ${c}: ${format(v)}`}</title>
                    </rect>
                    {valueLabels && !narrow && (
                      <text x={groupPad / 2 + j * barW + barW / 2} y={v >= 0 ? y0 - 5 : y0 + h + 13} textAnchor="middle" fill="var(--color-navy-800)" className="font-medium tabular-nums">
                        {format(v)}
                      </text>
                    )}
                  </g>
                );
              })}
              <text x={band / 2} y={ih + 18} textAnchor="middle" fill="var(--color-muted)">
                {narrow ? c.slice(0, 1) : c}
              </text>
            </g>
          ))}
          {line && (
            <g>
              <polyline
                fill="none"
                stroke={line.color}
                strokeWidth={2.25}
                points={line.values.map((v, i) => `${i * band + band / 2},${y(v)}`).join(' ')}
              />
              {line.values.map((v, i) => (
                <circle key={i} cx={i * band + band / 2} cy={y(v)} r={3.5} fill="white" stroke={line.color} strokeWidth={2}>
                  <title>{`${line.name} · ${categories[i]}: ${format(v)}`}</title>
                </circle>
              ))}
            </g>
          )}
        </g>
      </svg>
    </div>
  );
}
