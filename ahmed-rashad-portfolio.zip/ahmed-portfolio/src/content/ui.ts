/**
 * ============================================================
 *  INTERFACE TEXT (buttons, headings, labels, error messages)
 * ============================================================
 *  Each line is:   key: { en: 'English text', ar: 'النص العربي' },
 *  Only edit the text inside quotes. Do not rename the keys.
 * ============================================================
 */
const strings = {
  /* ----- Navigation ----- */
  'nav.home': { en: 'Home', ar: 'الرئيسية' },
  'nav.about': { en: 'About', ar: 'نبذة عني' },
  'nav.expertise': { en: 'Expertise', ar: 'الخبرات' },
  'nav.portfolio': { en: 'Portfolio', ar: 'دراسات الحالة' },
  'nav.tools': { en: 'Tools', ar: 'الأدوات المالية' },
  'nav.contact': { en: 'Contact', ar: 'تواصل معي' },
  'nav.main': { en: 'Main navigation', ar: 'التنقل الرئيسي' },
  'nav.open': { en: 'Open menu', ar: 'فتح القائمة' },
  'nav.close': { en: 'Close menu', ar: 'إغلاق القائمة' },
  skip: { en: 'Skip to content', ar: 'انتقل إلى المحتوى' },
  'lang.switch': { en: 'العربية', ar: 'English' },
  'lang.switchLabel': { en: 'View this page in Arabic', ar: 'عرض هذه الصفحة بالإنجليزية' },

  /* ----- Buttons ----- */
  'cta.portfolio': { en: 'View my portfolio', ar: 'استعرض أعمالي' },
  'cta.contact': { en: 'Contact me', ar: 'تواصل معي' },
  'cta.readCase': { en: 'Read the case study', ar: 'اقرأ دراسة الحالة' },
  'cta.allCases': { en: 'All case studies', ar: 'جميع دراسات الحالة' },
  'cta.email': { en: 'Send an email', ar: 'أرسل بريدًا إلكترونيًا' },
  'cta.linkedin': { en: 'Connect on LinkedIn', ar: 'تواصل عبر LinkedIn' },
  'cta.copy': { en: 'Copy address', ar: 'نسخ العنوان' },
  'cta.copied': { en: 'Copied', ar: 'تم النسخ' },
  'cta.calculator': { en: 'Open the break-even calculator', ar: 'افتح حاسبة نقطة التعادل' },
  'cta.aboutMore': { en: 'Full background', ar: 'الخلفية المهنية الكاملة' },
  'cta.expertiseMore': { en: 'All areas of expertise', ar: 'جميع مجالات الخبرة' },

  /* ----- Shared ----- */
  illustrative: { en: 'Illustrative data', ar: 'بيانات توضيحية' },
  illustrativeNote: {
    en: 'All figures are synthetic and created to demonstrate analytical method. They do not come from any employer or client.',
    ar: 'جميع الأرقام افتراضية أُعدّت لتوضيح منهجية التحليل، ولا تعود لأي جهة عمل أو عميل.',
  },
  unitK: { en: "SAR '000", ar: 'بآلاف الريالات' },
  newTab: { en: '(opens in a new tab)', ar: '(يفتح في نافذة جديدة)' },

  /* ----- Home ----- */
  'home.report.title': { en: 'H1 performance summary', ar: 'ملخص أداء النصف الأول' },
  'home.report.source': { en: 'From case study: Budgeting & Rolling Forecast', ar: 'من دراسة الحالة: الموازنة والتوقعات المتجددة' },
  'home.report.line': { en: 'Line', ar: 'البند' },
  'home.report.actual': { en: 'Actual', ar: 'الفعلي' },
  'home.report.budget': { en: 'Budget', ar: 'الموازنة' },
  'home.report.var': { en: 'Var.', ar: 'الانحراف' },
  'home.report.revenue': { en: 'Revenue', ar: 'الإيرادات' },
  'home.report.expenses': { en: 'Operating expenses', ar: 'المصروفات التشغيلية' },
  'home.report.profit': { en: 'Operating profit', ar: 'الربح التشغيلي' },
  'home.report.trend': { en: 'Monthly revenue against budget', ar: 'الإيرادات الشهرية مقابل الموازنة' },
  'home.report.takeaway': {
    en: 'Revenue is 2.1% short, but profit is 11% short. The commentary explains why, and what to do about it.',
    ar: 'الإيرادات أقل بنسبة 2.1%، لكن الربح أقل بنسبة 11%. التعليق التحليلي يشرح السبب والإجراء المطلوب.',
  },
  'home.focus.title': { en: 'Where I add value', ar: 'أين أضيف قيمة' },
  'home.cases.title': { en: 'Selected case studies', ar: 'دراسات حالة مختارة' },
  'home.cases.lede': {
    en: 'Three analyses built on synthetic data, each written the way I would present it to a management team: context, method, findings and recommendations.',
    ar: 'ثلاثة تحليلات مبنية على بيانات افتراضية، كُتب كل منها بالطريقة التي أعرضها على فريق الإدارة: السياق، والمنهجية، والنتائج، والتوصيات.',
  },
  'home.skills.title': { en: 'Credentials and tools', ar: 'المؤهلات والأدوات' },
  'home.closing.title': { en: 'Need a clearer view of your numbers?', ar: 'هل تحتاج إلى رؤية أوضح لأرقامك؟' },
  'home.closing.body': {
    en: 'I am open to conversations about financial analysis, FP&A, forecasting and reporting, whether for a role or a project.',
    ar: 'يسعدني الحديث حول التحليل المالي والتخطيط والتوقعات والتقارير، سواء لفرصة وظيفية أو لمشروع.',
  },

  /* ----- About ----- */
  'about.title': { en: 'About', ar: 'نبذة عني' },
  'about.lede': {
    en: 'An accountant by training and a financial analyst by role, focused on making financial information useful for decisions.',
    ar: 'محاسب بالتأهيل ومحلل مالي بالممارسة، أركّز على جعل المعلومات المالية مفيدة في اتخاذ القرارات.',
  },
  'about.career': { en: 'Career', ar: 'المسار المهني' },
  'about.how': { en: 'How the work fits together', ar: 'كيف تترابط مراحل العمل' },
  'about.how.lede': {
    en: 'Reporting, analysis and planning are one process. Each step depends on the quality of the one before it.',
    ar: 'التقارير والتحليل والتخطيط عملية واحدة، وكل مرحلة تعتمد على جودة المرحلة التي تسبقها.',
  },
  'about.certs': { en: 'Certifications', ar: 'الشهادات المهنية' },
  'about.education': { en: 'Education', ar: 'التعليم' },
  'about.learning': { en: 'Continuing development', ar: 'التطوير المستمر' },
  'about.tools': { en: 'Tools and systems', ar: 'الأدوات والأنظمة' },
  'about.languages': { en: 'Languages', ar: 'اللغات' },
  'about.achievement': { en: 'Recognition', ar: 'التقدير' },

  /* ----- Expertise ----- */
  'expertise.title': { en: 'Expertise', ar: 'الخبرات' },
  'expertise.lede': {
    en: 'Seven capabilities, each described by the business question it answers.',
    ar: 'سبع قدرات، تُعرض كل منها من خلال السؤال الذي تجيب عنه للأعمال.',
  },
  'expertise.purpose': { en: 'Why it matters', ar: 'لماذا يهم' },
  'expertise.work': { en: 'What the work includes', ar: 'ما يشمله العمل' },
  'expertise.output': { en: 'What management receives', ar: 'ما تحصل عليه الإدارة' },

  /* ----- Portfolio ----- */
  'portfolio.title': { en: 'Case studies', ar: 'دراسات الحالة' },
  'portfolio.lede': {
    en: 'Each case study uses synthetic data to show how I approach a common management question, from the first look at the numbers to a recommendation.',
    ar: 'تستخدم كل دراسة حالة بيانات افتراضية لتوضيح طريقتي في معالجة سؤال إداري شائع، من القراءة الأولى للأرقام حتى التوصية.',
  },
  'case.context': { en: 'Business context', ar: 'سياق الأعمال' },
  'case.problem': { en: 'The question', ar: 'المشكلة' },
  'case.approach': { en: 'Analytical approach', ar: 'منهجية التحليل' },
  'case.metrics': { en: 'Key metrics', ar: 'المؤشرات الرئيسية' },
  'case.analysis': { en: 'Analysis', ar: 'التحليل' },
  'case.metricsAnalysis': { en: 'Metrics and analysis', ar: 'المؤشرات والتحليل' },
  'case.findings': { en: 'Key findings', ar: 'أبرز النتائج' },
  'case.recommendations': { en: 'Recommendations to management', ar: 'التوصيات للإدارة' },
  'case.assumptions': { en: 'Key assumptions', ar: 'الافتراضات الرئيسية' },
  'case.next': { en: 'Next case study', ar: 'دراسة الحالة التالية' },
  'case.back': { en: 'Back to all case studies', ar: 'العودة إلى دراسات الحالة' },

  /* Case 1 charts */
  'c1.revenue': { en: 'Monthly revenue by branch', ar: 'الإيرادات الشهرية حسب الفرع' },
  'c1.cost': { en: 'Cost of sales as % of sales: standard vs actual', ar: 'تكلفة المبيعات كنسبة من المبيعات: المعيارية مقابل الفعلية' },
  'c1.mix': { en: 'Product mix (% of sales) and standard cost by category', ar: 'مزيج المنتجات (% من المبيعات) والتكلفة المعيارية حسب الفئة' },
  'c1.standard': { en: 'Standard', ar: 'المعيارية' },
  'c1.actual': { en: 'Actual', ar: 'الفعلية' },
  'c1.category': { en: 'Category', ar: 'الفئة' },
  'c1.stdCost': { en: 'Standard cost %', ar: 'التكلفة المعيارية %' },
  'c1.bridge': { en: 'Bridging the 6.0-point gap', ar: 'تفسير فجوة الـ6.0 نقاط' },
  'c1.bridge.a': { en: 'Branch A actual', ar: 'الفعلي — الفرع أ' },
  'c1.bridge.exA': { en: 'Less: Branch A execution', ar: 'ناقص: أثر التنفيذ — الفرع أ' },
  'c1.bridge.mix': { en: 'Product mix effect', ar: 'أثر مزيج المنتجات' },
  'c1.bridge.exB': { en: 'Branch B execution', ar: 'أثر التنفيذ — الفرع ب' },
  'c1.bridge.b': { en: 'Branch B actual', ar: 'الفعلي — الفرع ب' },

  /* Case 2 charts */
  'c2.trend': { en: 'Revenue: budget, actual and rolling forecast', ar: 'الإيرادات: الموازنة والفعلي والتوقعات المتجددة' },
  'c2.budget': { en: 'Budget', ar: 'الموازنة' },
  'c2.actual': { en: 'Actual', ar: 'الفعلي' },
  'c2.forecast': { en: 'Forecast (base)', ar: 'التوقع (أساسي)' },
  'c2.variance': { en: 'H1 variance by month', ar: 'انحرافات النصف الأول حسب الشهر' },
  'c2.month': { en: 'Month', ar: 'الشهر' },
  'c2.revVar': { en: 'Revenue variance', ar: 'انحراف الإيرادات' },
  'c2.expVar': { en: 'Expense variance', ar: 'انحراف المصروفات' },
  'c2.profitVar': { en: 'Profit impact', ar: 'الأثر على الربح' },
  'c2.total': { en: 'H1 total', ar: 'إجمالي النصف الأول' },
  'c2.scenarios': { en: 'Full-year outlook by scenario', ar: 'توقعات السنة الكاملة حسب السيناريو' },
  'c2.scenario': { en: 'Scenario', ar: 'السيناريو' },
  'c2.revenue': { en: 'Revenue', ar: 'الإيرادات' },
  'c2.expenses': { en: 'Expenses', ar: 'المصروفات' },
  'c2.profit': { en: 'Operating profit', ar: 'الربح التشغيلي' },
  'c2.vsBudget': { en: 'Profit vs budget', ar: 'الربح مقابل الموازنة' },
  'c2.varNote': {
    en: 'Positive profit impact is favourable. Expense overruns reduce profit.',
    ar: 'الأثر الموجب على الربح إيجابي. تجاوز المصروفات يخفض الربح.',
  },

  /* Case 3 charts */
  'c3.select': { en: 'Scenario', ar: 'السيناريو' },
  'c3.cash': { en: 'Annual and cumulative cash flow', ar: 'التدفق النقدي السنوي والتراكمي' },
  'c3.annual': { en: 'Annual cash flow', ar: 'التدفق السنوي' },
  'c3.cumulative': { en: 'Cumulative position', ar: 'الرصيد التراكمي' },
  'c3.year': { en: 'Year', ar: 'السنة' },
  'c3.y0': { en: 'Today', ar: 'اليوم' },
  'c3.npv': { en: 'NPV at 12%', ar: 'صافي القيمة الحالية بمعدل 12%' },
  'c3.irr': { en: 'IRR', ar: 'معدل العائد الداخلي' },
  'c3.payback': { en: 'Payback', ar: 'فترة الاسترداد' },
  'c3.discPayback': { en: 'Discounted payback', ar: 'فترة الاسترداد المخصومة' },
  'c3.notRecovered': { en: 'Not within 5 years', ar: 'لا يُسترد خلال 5 سنوات' },
  'c3.hurdle': { en: 'Hurdle rate 12%', ar: 'العائد المطلوب 12%' },
  'c3.sensitivity': { en: 'NPV sensitivity', ar: 'حساسية صافي القيمة الحالية' },
  'c3.sensitivity.note': {
    en: 'Rows change the discount rate; columns change all inflows against the base case.',
    ar: 'تغيّر الصفوف معدل الخصم، وتغيّر الأعمدة جميع التدفقات مقارنة بالسيناريو الأساسي.',
  },
  'c3.rate': { en: 'Discount rate', ar: 'معدل الخصم' },
  'c3.compare': { en: 'Scenario comparison', ar: 'مقارنة السيناريوهات' },
  'c3.decision': { en: 'Meets the 12% hurdle', ar: 'يحقق العائد المطلوب 12%' },
  yes: { en: 'Yes', ar: 'نعم' },
  no: { en: 'No', ar: 'لا' },
  years: { en: 'years', ar: 'سنوات' },

  /* ----- Tools ----- */
  'tools.title': { en: 'Break-even calculator', ar: 'حاسبة نقطة التعادل' },
  'tools.lede': {
    en: 'Find how many units you need to sell to cover your costs, and how far current sales sit above or below that point. Calculations run in your browser; nothing is sent anywhere.',
    ar: 'احسب عدد الوحدات التي تحتاج إلى بيعها لتغطية تكاليفك، ومدى ابتعاد مبيعاتك الحالية عن هذه النقطة. تتم الحسابات داخل متصفحك، ولا تُرسل أي بيانات.',
  },
  'tools.inputs': { en: 'Your figures', ar: 'أرقامك' },
  'tools.price': { en: 'Selling price per unit', ar: 'سعر البيع للوحدة' },
  'tools.variable': { en: 'Variable cost per unit', ar: 'التكلفة المتغيرة للوحدة' },
  'tools.fixed': { en: 'Total fixed costs', ar: 'إجمالي التكاليف الثابتة' },
  'tools.fixed.hint': { en: 'For the same period as current sales, e.g. per month', ar: 'لنفس فترة المبيعات الحالية، مثلًا شهريًا' },
  'tools.current': { en: 'Current sales volume (units)', ar: 'حجم المبيعات الحالي (بالوحدات)' },
  'tools.optional': { en: 'Optional', ar: 'اختياري' },
  'tools.currency': { en: 'Currency', ar: 'العملة' },
  'tools.example': { en: 'Load an example', ar: 'تحميل مثال' },
  'tools.clear': { en: 'Clear', ar: 'مسح' },
  'tools.results': { en: 'Results', ar: 'النتائج' },
  'tools.empty': {
    en: 'Enter a selling price, variable cost and fixed costs to see your break-even point.',
    ar: 'أدخل سعر البيع والتكلفة المتغيرة والتكاليف الثابتة لعرض نقطة التعادل.',
  },
  'tools.cm': { en: 'Contribution margin per unit', ar: 'هامش المساهمة للوحدة' },
  'tools.cm.hint': { en: 'Price minus variable cost', ar: 'السعر ناقص التكلفة المتغيرة' },
  'tools.cmr': { en: 'Contribution margin ratio', ar: 'نسبة هامش المساهمة' },
  'tools.cmr.hint': { en: 'Share of each sale left to cover fixed costs', ar: 'الجزء المتبقي من كل عملية بيع لتغطية التكاليف الثابتة' },
  'tools.beUnits': { en: 'Break-even units', ar: 'وحدات التعادل' },
  'tools.beUnits.hint': { en: 'Rounded up to whole units', ar: 'مقرّبة لأعلى إلى وحدات كاملة' },
  'tools.beRevenue': { en: 'Break-even sales revenue', ar: 'إيرادات التعادل' },
  'tools.beRevenue.hint': { en: 'Fixed costs ÷ contribution margin ratio', ar: 'التكاليف الثابتة ÷ نسبة هامش المساهمة' },
  'tools.mos': { en: 'Margin of safety', ar: 'هامش الأمان' },
  'tools.mos.hint': { en: 'How far sales can fall before a loss', ar: 'مقدار انخفاض المبيعات الممكن قبل تحقيق خسارة' },
  'tools.mos.below': { en: 'Below break-even by', ar: 'دون نقطة التعادل بمقدار' },
  'tools.mos.none': { en: 'Add current sales volume to calculate', ar: 'أضف حجم المبيعات الحالي للحساب' },
  'tools.profit': { en: 'Profit at current volume', ar: 'الربح عند الحجم الحالي' },
  'tools.units': { en: 'units', ar: 'وحدة' },
  'tools.ofSales': { en: 'of current sales', ar: 'من المبيعات الحالية' },
  'tools.chart': { en: 'Break-even sales vs current sales', ar: 'إيرادات التعادل مقابل المبيعات الحالية' },
  'tools.chart.be': { en: 'Break-even sales', ar: 'إيرادات التعادل' },
  'tools.chart.current': { en: 'Current sales', ar: 'المبيعات الحالية' },
  'tools.chart.noCurrent': {
    en: 'Add your current sales volume to compare it with break-even.',
    ar: 'أضف حجم مبيعاتك الحالي لمقارنته بنقطة التعادل.',
  },
  'tools.status.above': { en: 'Current sales are above break-even.', ar: 'المبيعات الحالية أعلى من نقطة التعادل.' },
  'tools.status.below': { en: 'Current sales are below break-even: the business is making a loss at this volume.', ar: 'المبيعات الحالية دون نقطة التعادل: النشاط يحقق خسارة عند هذا الحجم.' },
  'tools.status.at': { en: 'Current sales are at break-even.', ar: 'المبيعات الحالية عند نقطة التعادل.' },
  'tools.cvp': { en: 'Cost-volume-profit', ar: 'التكلفة والحجم والربح' },
  'tools.cvp.note': { en: 'Below the break-even line costs exceed revenue; above it each unit adds profit.', ar: 'قبل خط التعادل تتجاوز التكاليف الإيرادات، وبعده تضيف كل وحدة ربحًا.' },
  'tools.cvp.revenue': { en: 'Revenue', ar: 'الإيرادات' },
  'tools.cvp.cost': { en: 'Total cost', ar: 'إجمالي التكلفة' },
  'tools.cvp.fixed': { en: 'Fixed costs', ar: 'التكاليف الثابتة' },
  'tools.cvp.be': { en: 'Break-even', ar: 'التعادل' },
  'tools.cvp.axis': { en: 'Horizontal axis: units sold. Vertical axis: amount.', ar: 'المحور الأفقي: الوحدات المباعة. المحور الرأسي: المبلغ.' },
  'tools.method': { en: 'How it is calculated', ar: 'طريقة الحساب' },
  'tools.method.body': {
    en: 'Contribution margin = price − variable cost. Break-even units = fixed costs ÷ contribution margin. Break-even revenue = break-even units × price. Margin of safety = current sales − break-even sales. The model assumes a constant price and variable cost per unit across the volume range.',
    ar: 'هامش المساهمة = السعر − التكلفة المتغيرة. وحدات التعادل = التكاليف الثابتة ÷ هامش المساهمة. إيرادات التعادل = وحدات التعادل × السعر. هامش الأمان = المبيعات الحالية − مبيعات التعادل. يفترض النموذج ثبات السعر والتكلفة المتغيرة للوحدة على جميع مستويات الحجم.',
  },

  /* Calculator errors */
  'err.required': { en: 'Enter a value.', ar: 'أدخل قيمة.' },
  'err.number': { en: 'Enter a number, e.g. 125 or 125.50.', ar: 'أدخل رقمًا، مثل 125 أو 125.50.' },
  'err.negative': { en: 'This cannot be negative.', ar: 'لا يمكن أن تكون القيمة سالبة.' },
  'err.pricePositive': { en: 'Selling price must be greater than zero.', ar: 'يجب أن يكون سعر البيع أكبر من صفر.' },
  'err.tooLarge': { en: 'This number is too large to calculate reliably.', ar: 'هذا الرقم كبير جدًا للحساب بدقة.' },
  'err.margin.zero': {
    en: 'Variable cost equals the selling price, so each sale contributes nothing toward fixed costs. Break-even cannot be reached. Raise the price or lower the variable cost.',
    ar: 'التكلفة المتغيرة تساوي سعر البيع، أي أن كل عملية بيع لا تساهم في تغطية التكاليف الثابتة، ولا يمكن الوصول إلى نقطة التعادل. ارفع السعر أو خفّض التكلفة المتغيرة.',
  },
  'err.margin.negative': {
    en: 'Variable cost is higher than the selling price, so every unit sold increases the loss. Break-even cannot be reached. Raise the price or lower the variable cost.',
    ar: 'التكلفة المتغيرة أعلى من سعر البيع، أي أن كل وحدة مباعة تزيد الخسارة، ولا يمكن الوصول إلى نقطة التعادل. ارفع السعر أو خفّض التكلفة المتغيرة.',
  },

  /* ----- Contact ----- */
  'contact.title': { en: 'Contact', ar: 'تواصل معي' },
  'contact.lede': {
    en: 'If you are looking for support with financial analysis, FP&A, forecasting or management reporting, or want to discuss a role, I would be glad to hear from you.',
    ar: 'إذا كنت تبحث عن دعم في التحليل المالي أو التخطيط المالي أو التوقعات أو التقارير الإدارية، أو ترغب في مناقشة فرصة وظيفية، يسعدني تواصلك.',
  },
  'contact.topics': { en: 'Good reasons to get in touch', ar: 'موضوعات يسعدني مناقشتها' },
  'contact.t1': { en: 'Monthly reporting and KPI packs', ar: 'التقارير الشهرية وحزم مؤشرات الأداء' },
  'contact.t2': { en: 'Budgets, forecasts and variance reviews', ar: 'الموازنات والتوقعات ومراجعات الانحرافات' },
  'contact.t3': { en: 'Cash flow and investment models', ar: 'نماذج التدفقات النقدية والاستثمار' },
  'contact.t4': { en: 'Power BI dashboards', ar: 'لوحات Power BI' },
  'contact.t5': { en: 'Full-time and consulting opportunities', ar: 'الفرص الوظيفية والاستشارية' },
  'contact.email': { en: 'Email', ar: 'البريد الإلكتروني' },
  'contact.linkedin': { en: 'LinkedIn', ar: 'LinkedIn' },
  'contact.hint': {
    en: 'A short note on what you are working on and the timeline helps me reply with something useful.',
    ar: 'رسالة قصيرة عمّا تعمل عليه والإطار الزمني تساعدني على الرد بشكل مفيد.',
  },

  /* ----- Footer & 404 ----- */
  'footer.note': {
    en: 'Case studies use synthetic data for illustration only.',
    ar: 'تستخدم دراسات الحالة بيانات افتراضية لأغراض التوضيح فقط.',
  },
  '404.title': { en: 'Page not found', ar: 'الصفحة غير موجودة' },
  '404.body': { en: 'The address may be mistyped, or the page has moved.', ar: 'ربما كُتب العنوان بشكل خاطئ، أو نُقلت الصفحة.' },
  '404.home': { en: 'Go to the home page', ar: 'الذهاب إلى الصفحة الرئيسية' },

  /* ----- Page titles & search-engine descriptions ----- */
  'meta.home.title': { en: 'Ahmed Rashad Hussein | Senior Financial Analyst', ar: 'أحمد رشاد حسين | محلل مالي أول' },
  'meta.home.desc': {
    en: 'Senior Financial Analyst specialising in FP&A, financial modeling and business performance analysis. Case studies, a break-even calculator and contact details.',
    ar: 'محلل مالي أول متخصص في التخطيط والتحليل المالي والنمذجة المالية وتحليل أداء الأعمال. دراسات حالة وحاسبة نقطة التعادل وبيانات التواصل.',
  },
  'meta.about.title': { en: 'About | Ahmed Rashad Hussein', ar: 'نبذة عني | أحمد رشاد حسين' },
  'meta.about.desc': {
    en: 'Career, certifications (AFM, FPAP, FMVA), education and tools of Senior Financial Analyst Ahmed Rashad Hussein.',
    ar: 'المسار المهني والشهادات (AFM و FPAP و FMVA) والتعليم والأدوات للمحلل المالي الأول أحمد رشاد حسين.',
  },
  'meta.expertise.title': { en: 'Expertise | Ahmed Rashad Hussein', ar: 'الخبرات | أحمد رشاد حسين' },
  'meta.expertise.desc': {
    en: 'FP&A, budgeting and forecasting, financial modeling, variance analysis, cash flow scenarios, Power BI dashboards and profitability analysis.',
    ar: 'التخطيط والتحليل المالي، الموازنات والتوقعات، النمذجة المالية، تحليل الانحرافات، سيناريوهات التدفقات النقدية، لوحات Power BI وتحليل الربحية.',
  },
  'meta.portfolio.title': { en: 'Case Studies | Ahmed Rashad Hussein', ar: 'دراسات الحالة | أحمد رشاد حسين' },
  'meta.portfolio.desc': {
    en: 'Illustrative financial analysis case studies: branch performance, budgeting and forecasting, and investment evaluation.',
    ar: 'دراسات حالة توضيحية في التحليل المالي: أداء الفروع، والموازنات والتوقعات، وتقييم الاستثمار.',
  },
  'meta.tools.title': { en: 'Break-even Calculator | Ahmed Rashad Hussein', ar: 'حاسبة نقطة التعادل | أحمد رشاد حسين' },
  'meta.tools.desc': {
    en: 'Free break-even calculator: contribution margin, break-even units and revenue, and margin of safety.',
    ar: 'حاسبة مجانية لنقطة التعادل: هامش المساهمة ووحدات وإيرادات التعادل وهامش الأمان.',
  },
  'meta.contact.title': { en: 'Contact | Ahmed Rashad Hussein', ar: 'تواصل معي | أحمد رشاد حسين' },
  'meta.contact.desc': {
    en: 'Get in touch about financial analysis, FP&A, forecasting, reporting and professional opportunities.',
    ar: 'تواصل بخصوص التحليل المالي والتخطيط المالي والتوقعات والتقارير والفرص المهنية.',
  },
} as const;

export type UiKey = keyof typeof strings;
export const ui: Record<UiKey, { en: string; ar: string }> = strings;
