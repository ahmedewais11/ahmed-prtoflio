/**
 * ============================================================
 *  YOUR PERSONAL INFORMATION
 * ============================================================
 *  This is the main file to edit. Every text has an English (en)
 *  and an Arabic (ar) version. Change the words between the quotes
 *  and save the file — the website updates automatically.
 *
 *  Rule of thumb: only change text inside quotes '...'.
 *  Keep the commas, brackets and the en: / ar: labels as they are.
 * ============================================================
 */
import type { Bilingual } from '../i18n/types';

export const profile = {
  name: { en: 'Ahmed Rashad Hussein', ar: 'أحمد رشاد حسين' } as Bilingual,
  title: { en: 'Senior Financial Analyst', ar: 'محلل مالي أول' } as Bilingual,
  positioning: {
    en: 'Senior Financial Analyst | FP&A | Financial Modeling | Business Performance Analysis',
    ar: 'محلل مالي أول | التخطيط والتحليل المالي | النمذجة المالية | تحليل أداء الأعمال',
  } as Bilingual,
  brandStatement: {
    en: 'Turning Financial Data into Strategic Business Decisions.',
    ar: 'تحويل البيانات المالية إلى رؤى تدعم القرارات الاستراتيجية وتحسين الأداء.',
  } as Bilingual,
  intro: {
    en: 'I prepare the monthly reports, budgets, forecasts and cash flow models that management teams use to understand where the business stands and decide what to do next. My work sits between the general ledger and the boardroom: making the numbers accurate, then making them useful.',
    ar: 'أُعِدّ التقارير الشهرية والموازنات والتوقعات ونماذج التدفقات النقدية التي تعتمد عليها الإدارة لفهم موقف الأعمال وتحديد الخطوة التالية. يقع عملي بين دفتر الأستاذ العام وطاولة الإدارة: أن تكون الأرقام دقيقة أولًا، ثم أن تكون مفيدة في اتخاذ القرار.',
  } as Bilingual,

  // Contact details. Phone numbers are intentionally NOT published.
  email: 'ahmeddrashad110@gmail.com',
  linkedin: 'https://www.linkedin.com/in/ahmed-ewais-37b388184',

  // Short initials shown in the logo mark (top corner of the site).
  initials: 'AR',

  // After you buy a domain, put it here (used for social-sharing links). Example: 'https://ahmedrashad.com'
  siteUrl: 'https://YOUR-SITE.netlify.app',
};

/* ---------------- Career timeline (newest first) ---------------- */
export const experience = [
  {
    company: { en: 'Erad Accounting Consulting', ar: 'Erad Accounting Consulting' } as Bilingual,
    location: { en: 'Remote — Saudi Arabia', ar: 'عن بُعد — المملكة العربية السعودية' } as Bilingual,
    roles: [
      {
        title: { en: 'Senior Financial Analyst', ar: 'محلل مالي أول' } as Bilingual,
        period: { en: 'Sep 2025 – Present', ar: 'سبتمبر 2025 – حتى الآن' } as Bilingual,
      },
      {
        title: { en: 'Junior Financial Analyst', ar: 'محلل مالي مبتدئ' } as Bilingual,
        period: { en: 'Sep 2024 – Aug 2025', ar: 'سبتمبر 2024 – أغسطس 2025' } as Bilingual,
      },
    ],
    responsibilities: [
      { en: 'Monthly financial reporting and KPI analysis for management', ar: 'إعداد التقارير المالية الشهرية وتحليل مؤشرات الأداء للإدارة' },
      { en: 'Budgeting, financial forecasting and sales forecasts', ar: 'إعداد الموازنات والتوقعات المالية وتوقعات المبيعات' },
      { en: 'Cash flow modeling, scenario and sensitivity analysis', ar: 'نمذجة التدفقات النقدية وتحليل السيناريوهات والحساسية' },
      { en: 'Variance analysis and financial performance reviews', ar: 'تحليل الانحرافات ومراجعات الأداء المالي' },
      { en: 'Financial ratio and profitability analysis', ar: 'تحليل النسب المالية والربحية' },
      { en: 'Power BI dashboards and management reporting', ar: 'لوحات Power BI والتقارير الإدارية' },
      { en: 'Working with clients to explain results and the actions they point to', ar: 'التعاون مع العملاء لشرح النتائج والإجراءات التي تشير إليها' },
    ] as Bilingual[],
  },
  {
    company: { en: 'White Shark & White Bus Company', ar: 'White Shark & White Bus Company' } as Bilingual,
    location: { en: 'Egypt', ar: 'مصر' } as Bilingual,
    roles: [
      {
        title: { en: 'Financial Accountant', ar: 'محاسب مالي' } as Bilingual,
        period: { en: 'Nov 2023 – Sep 2024', ar: 'نوفمبر 2023 – سبتمبر 2024' } as Bilingual,
      },
    ],
    responsibilities: [
      { en: 'Financial accounting and general ledger maintenance', ar: 'المحاسبة المالية وإدارة دفتر الأستاذ العام' },
      { en: 'Preparing spending reports for management', ar: 'إعداد تقارير المصروفات للإدارة' },
    ] as Bilingual[],
  },
];

/* ---------------- Achievement ---------------- */
export const achievement: Bilingual = {
  en: 'Scored 97% in the 2025 performance evaluation.',
  ar: 'حصلت على تقييم أداء بنسبة 97% في عام 2025.',
};

/* ---------------- Certifications (newest first) ----------------
   Official certificate names stay in English on both language versions. */
export const certifications = [
  {
    short: 'AFM',
    issuerShort: 'FMI',
    name: { en: 'Advanced Financial Modeler (AFM)', ar: 'Advanced Financial Modeler (AFM)' } as Bilingual,
    issuer: { en: 'Financial Modeling Institute', ar: 'Financial Modeling Institute' } as Bilingual,
    date: { en: 'June 2026', ar: 'يونيو 2026' } as Bilingual,
  },
  {
    short: 'FPAP',
    issuerShort: 'CFI',
    name: { en: 'Financial Planning & Analysis Professional (FPAP)', ar: 'Financial Planning & Analysis Professional (FPAP)' } as Bilingual,
    issuer: { en: 'Corporate Finance Institute', ar: 'Corporate Finance Institute' } as Bilingual,
    date: { en: 'October 2025', ar: 'أكتوبر 2025' } as Bilingual,
  },
  {
    short: 'FMVA',
    issuerShort: 'CFI',
    name: { en: 'Financial Modeling & Valuation Analyst (FMVA)', ar: 'Financial Modeling & Valuation Analyst (FMVA)' } as Bilingual,
    issuer: { en: 'Corporate Finance Institute', ar: 'Corporate Finance Institute' } as Bilingual,
    date: { en: 'April 2025', ar: 'أبريل 2025' } as Bilingual,
  },
];

/* ---------------- Education & learning ---------------- */
export const education = {
  degree: { en: "Bachelor's degree in Commerce — Accounting (English Section)", ar: 'بكالوريوس التجارة — شعبة المحاسبة (القسم الإنجليزي)' } as Bilingual,
  school: { en: 'South Valley University', ar: 'جامعة جنوب الوادي' } as Bilingual,
  grade: { en: 'Overall grade: Very Good', ar: 'التقدير العام: جيد جدًا' } as Bilingual,
};

export const learning: Bilingual[] = [
  { en: 'IFRS (self-study)', ar: 'المعايير الدولية لإعداد التقارير المالية IFRS (دراسة ذاتية)' },
  { en: 'Additional Excel and Power BI training', ar: 'تدريب إضافي على Excel و Power BI' },
];

/* ---------------- Tools ---------------- */
export const tools = [
  {
    group: { en: 'Spreadsheets & modeling', ar: 'الجداول والنمذجة' } as Bilingual,
    items: ['Advanced Excel', 'Pivot Tables', 'VLOOKUP', 'Power Query', 'Google Sheets'],
  },
  {
    group: { en: 'Reporting & BI', ar: 'التقارير وذكاء الأعمال' } as Bilingual,
    items: ['Microsoft Power BI'],
  },
  {
    group: { en: 'ERP & accounting systems', ar: 'أنظمة ERP والمحاسبة' } as Bilingual,
    items: ['Odoo', 'Dafater', 'Qoyod', 'QuickBooks', 'Foodics'],
  },
];

export const languages = [
  { name: { en: 'Arabic', ar: 'العربية' } as Bilingual, level: { en: 'Native', ar: 'اللغة الأم' } as Bilingual },
  { name: { en: 'English', ar: 'الإنجليزية' } as Bilingual, level: { en: 'Full professional proficiency', ar: 'إتقان مهني كامل' } as Bilingual },
];
