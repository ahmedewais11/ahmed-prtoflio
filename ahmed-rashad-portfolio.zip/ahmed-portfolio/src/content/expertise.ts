/**
 * ============================================================
 *  EXPERTISE & ABOUT TEXT
 * ============================================================
 *  Edit the wording freely. Each item has English (en) and Arabic (ar).
 * ============================================================
 */
import type { Bilingual } from '../i18n/types';

/** The three focus areas shown on the home page. */
export const focusAreas: { title: Bilingual; body: Bilingual }[] = [
  {
    title: { en: 'FP&A', ar: 'التخطيط والتحليل المالي' },
    body: {
      en: 'Budgets, rolling forecasts and variance reviews that tell management whether the year is on track, and what to change if it is not.',
      ar: 'موازنات وتوقعات متجددة ومراجعات للانحرافات تُبيّن للإدارة ما إذا كانت السنة تسير وفق الخطة، وما الذي يجب تغييره إن لم تكن كذلك.',
    },
  },
  {
    title: { en: 'Financial Modeling', ar: 'النمذجة المالية' },
    body: {
      en: 'Cash flow and investment models with clear assumptions, scenarios and sensitivities, built so a decision-maker can see what drives the answer.',
      ar: 'نماذج للتدفقات النقدية والاستثمار بافتراضات واضحة وسيناريوهات وتحليل حساسية، مبنية ليرى صاحب القرار ما الذي يحرّك النتيجة.',
    },
  },
  {
    title: { en: 'Business Performance Analysis', ar: 'تحليل أداء الأعمال' },
    body: {
      en: 'KPI reporting, profitability and cost analysis that explain why results moved, not only by how much.',
      ar: 'تقارير مؤشرات الأداء وتحليل الربحية والتكاليف التي تشرح سبب تغيّر النتائج، وليس مقدار التغيّر فقط.',
    },
  },
];

/** The seven capabilities on the Expertise page. */
export const capabilities: { id: string; title: Bilingual; purpose: Bilingual; work: Bilingual[]; output: Bilingual }[] = [
  {
    id: 'fpa',
    title: { en: 'Financial Planning & Analysis (FP&A)', ar: 'التخطيط والتحليل المالي (FP&A)' },
    purpose: {
      en: 'Connects the plan to what is actually happening, so leadership can steer the business during the year instead of explaining it afterwards.',
      ar: 'يربط الخطة بما يحدث فعليًا، لتتمكن الإدارة من توجيه الأعمال خلال السنة بدلًا من تفسير النتائج بعد انتهائها.',
    },
    work: [
      { en: 'Monthly performance packs combining results, KPIs and commentary', ar: 'تقارير أداء شهرية تجمع النتائج ومؤشرات الأداء والتعليق التحليلي' },
      { en: 'Financial performance reviews with management', ar: 'مراجعات الأداء المالي مع الإدارة' },
      { en: 'Financial ratio analysis to track liquidity, efficiency and returns', ar: 'تحليل النسب المالية لمتابعة السيولة والكفاءة والعوائد' },
    ],
    output: { en: 'A clear monthly view of where the business stands against plan.', ar: 'رؤية شهرية واضحة لموقف الأعمال مقارنة بالخطة.' },
  },
  {
    id: 'budgeting',
    title: { en: 'Budgeting and Forecasting', ar: 'الموازنات والتوقعات' },
    purpose: {
      en: 'Gives the business a realistic target and an updated view of the year, so hiring, purchasing and cash decisions are based on what is likely, not what was hoped.',
      ar: 'يمنح الشركة هدفًا واقعيًا ورؤية محدّثة للسنة، لتُبنى قرارات التوظيف والمشتريات والسيولة على ما هو مرجّح وليس على ما كان مأمولًا.',
    },
    work: [
      { en: 'Annual budgets built from revenue and cost drivers', ar: 'موازنات سنوية مبنية على محركات الإيرادات والتكاليف' },
      { en: 'Sales forecasts and rolling forecasts updated with actuals', ar: 'توقعات المبيعات وتوقعات متجددة تُحدَّث بالفعلي' },
      { en: 'Budget-versus-actual tracking', ar: 'متابعة الفعلي مقابل الموازنة' },
    ],
    output: { en: 'A forecast management can plan around, with the assumptions written down.', ar: 'توقعات يمكن للإدارة التخطيط على أساسها، مع توثيق الافتراضات.' },
  },
  {
    id: 'modeling',
    title: { en: 'Financial Modeling and Valuation', ar: 'النمذجة المالية والتقييم' },
    purpose: {
      en: 'Turns a proposal into numbers that can be tested, so an investment or pricing decision is made with its risks in view.',
      ar: 'يحوّل المقترح إلى أرقام قابلة للاختبار، ليُتخذ قرار الاستثمار أو التسعير والمخاطر واضحة أمام صاحب القرار.',
    },
    work: [
      { en: 'Structured models with separated inputs, calculations and outputs', ar: 'نماذج منظمة تفصل المدخلات عن الحسابات والمخرجات' },
      { en: 'NPV, IRR and payback analysis for investment decisions', ar: 'تحليل صافي القيمة الحالية ومعدل العائد الداخلي وفترة الاسترداد لقرارات الاستثمار' },
      { en: 'Valuation work grounded in FMVA and AFM training', ar: 'أعمال التقييم المستندة إلى تدريب FMVA و AFM' },
    ],
    output: { en: 'A model a reviewer can follow, check and reuse.', ar: 'نموذج يستطيع المراجع تتبعه والتحقق منه وإعادة استخدامه.' },
  },
  {
    id: 'reporting',
    title: { en: 'Financial Reporting and Variance Analysis', ar: 'التقارير المالية وتحليل الانحرافات' },
    purpose: {
      en: 'Explains the gap between expected and actual results in plain terms, so the right person can act on the right cause.',
      ar: 'يشرح الفجوة بين النتائج المتوقعة والفعلية بلغة واضحة، ليتعامل الشخص المناسب مع السبب الحقيقي.',
    },
    work: [
      { en: 'Monthly financial reporting for management and clients', ar: 'التقارير المالية الشهرية للإدارة والعملاء' },
      { en: 'Variance analysis by line, period and business unit', ar: 'تحليل الانحرافات حسب البند والفترة ووحدة الأعمال' },
      { en: 'Spending reports and general ledger review', ar: 'تقارير المصروفات ومراجعة دفتر الأستاذ العام' },
    ],
    output: { en: 'Variance commentary that names the driver and the owner.', ar: 'تعليق على الانحرافات يحدد السبب والمسؤول.' },
  },
  {
    id: 'cashflow',
    title: { en: 'Cash Flow Modeling and Scenario Analysis', ar: 'نمذجة التدفقات النقدية وتحليل السيناريوهات' },
    purpose: {
      en: 'Shows whether the business can fund its plans under different conditions, before a cash shortfall becomes a problem.',
      ar: 'يوضح قدرة الشركة على تمويل خططها في ظروف مختلفة، قبل أن يتحول نقص السيولة إلى مشكلة.',
    },
    work: [
      { en: 'Cash flow projections linked to the operating forecast', ar: 'توقعات التدفقات النقدية المرتبطة بالتوقعات التشغيلية' },
      { en: 'Downside, base and upside scenarios', ar: 'سيناريوهات متحفظة وأساسية ومتفائلة' },
      { en: 'Sensitivity analysis on the assumptions that matter most', ar: 'تحليل الحساسية للافتراضات الأكثر تأثيرًا' },
    ],
    output: { en: 'A range of outcomes, and the trigger points that should prompt action.', ar: 'نطاق من النتائج المحتملة ونقاط الإنذار التي تستدعي التحرك.' },
  },
  {
    id: 'kpi',
    title: { en: 'KPI Development and Power BI Dashboarding', ar: 'تطوير مؤشرات الأداء ولوحات Power BI' },
    purpose: {
      en: 'Puts the few numbers that matter in front of the people who need them, refreshed without manual rework every month.',
      ar: 'يضع الأرقام القليلة المهمة أمام من يحتاجها، مع تحديثها دون إعادة عمل يدوي كل شهر.',
    },
    work: [
      { en: 'Defining KPIs that link to how the business makes money', ar: 'تحديد مؤشرات أداء مرتبطة بطريقة تحقيق الشركة لأرباحها' },
      { en: 'Power BI dashboards for management reporting', ar: 'لوحات Power BI للتقارير الإدارية' },
      { en: 'Data preparation with Power Query and ERP exports', ar: 'تجهيز البيانات باستخدام Power Query ومخرجات أنظمة ERP' },
    ],
    output: { en: 'A dashboard that answers the questions management actually asks.', ar: 'لوحة تجيب عن الأسئلة التي تطرحها الإدارة فعلًا.' },
  },
  {
    id: 'cost',
    title: { en: 'Cost and Profitability Analysis', ar: 'تحليل التكاليف والربحية' },
    purpose: {
      en: 'Finds where margin is earned and where it leaks, by product, branch or customer, so pricing and cost decisions target the right place.',
      ar: 'يحدد مصادر الهامش ومواضع تسربه حسب المنتج أو الفرع أو العميل، لتستهدف قرارات التسعير والتكلفة الموضع الصحيح.',
    },
    work: [
      { en: 'Profitability analysis by product, branch and category', ar: 'تحليل الربحية حسب المنتج والفرع والفئة' },
      { en: 'Standard versus actual cost comparisons', ar: 'مقارنة التكلفة المعيارية بالفعلية' },
      { en: 'Break-even and contribution margin analysis', ar: 'تحليل نقطة التعادل وهامش المساهمة' },
    ],
    output: { en: 'A ranked list of margin opportunities with their value.', ar: 'قائمة مرتبة بفرص تحسين الهامش وقيمة كل منها.' },
  },
];

/** About page: biography paragraphs. */
export const bio: Bilingual[] = [
  {
    en: 'I am a Senior Financial Analyst at Erad Accounting Consulting, working remotely with businesses in Saudi Arabia. I joined as a Junior Financial Analyst in September 2024 and moved into the senior role in September 2025.',
    ar: 'أعمل محللًا ماليًا أول في Erad Accounting Consulting، عن بُعد مع شركات في المملكة العربية السعودية. انضممت بوظيفة محلل مالي مبتدئ في سبتمبر 2024، ثم انتقلت إلى منصب محلل مالي أول في سبتمبر 2025.',
  },
  {
    en: 'My work covers the full cycle from reporting to planning: monthly financial reports and KPI analysis, budgets and forecasts, cash flow models, and the variance reviews that link them together. I build Power BI dashboards for management reporting and work directly with clients to explain what the numbers mean for their decisions.',
    ar: 'يغطي عملي الدورة الكاملة من إعداد التقارير إلى التخطيط: التقارير المالية الشهرية وتحليل مؤشرات الأداء، والموازنات والتوقعات، ونماذج التدفقات النقدية، ومراجعات الانحرافات التي تربط بينها. أبني لوحات Power BI للتقارير الإدارية، وأعمل مباشرة مع العملاء لشرح ما تعنيه الأرقام لقراراتهم.',
  },
  {
    en: 'Before moving into analysis, I worked as a Financial Accountant at White Shark & White Bus Company in Egypt, handling the general ledger and spending reports. That accounting foundation is why I start every analysis by making sure the underlying numbers are right.',
    ar: 'قبل الانتقال إلى التحليل المالي، عملت محاسبًا ماليًا في White Shark & White Bus Company في مصر، حيث توليت دفتر الأستاذ العام وتقارير المصروفات. هذا الأساس المحاسبي هو سبب حرصي على بدء كل تحليل بالتأكد من صحة الأرقام الأساسية.',
  },
];

/** About page: how the work fits together (a real sequence, so it is numbered). */
export const workflow: { title: Bilingual; body: Bilingual }[] = [
  { title: { en: 'Record', ar: 'التسجيل' }, body: { en: 'Clean, reconciled ledger data from the ERP.', ar: 'بيانات دفتر أستاذ نظيفة ومطابقة من نظام ERP.' } },
  { title: { en: 'Report', ar: 'التقرير' }, body: { en: 'Monthly results and KPIs in a consistent format.', ar: 'نتائج شهرية ومؤشرات أداء بصيغة ثابتة.' } },
  { title: { en: 'Analyze', ar: 'التحليل' }, body: { en: 'Variances, ratios and profitability explained by driver.', ar: 'الانحرافات والنسب والربحية مفسرة حسب السبب.' } },
  { title: { en: 'Plan', ar: 'التخطيط' }, body: { en: 'Budgets, forecasts and cash flow scenarios.', ar: 'الموازنات والتوقعات وسيناريوهات التدفقات النقدية.' } },
  { title: { en: 'Decide', ar: 'القرار' }, body: { en: 'Clear options and recommendations for management.', ar: 'خيارات وتوصيات واضحة للإدارة.' } },
];
