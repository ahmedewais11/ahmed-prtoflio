/**
 * ============================================================
 *  ILLUSTRATIVE CASE STUDIES
 * ============================================================
 *  All companies, branches and figures here are SYNTHETIC.
 *  They demonstrate analytical method only and do not come from
 *  any employer or client. Amounts are in thousands (SAR '000).
 *
 *  If you change a number in `data`, also update any sentence in
 *  `findings` that quotes it. Case study 3's metrics (NPV, IRR,
 *  payback) are calculated automatically from its cash flows.
 * ============================================================
 */
import type { Bilingual } from '../i18n/types';

export type Kpi = {
  label: Bilingual;
  value: number;
  format: 'k' | 'pct' | 'pp' | 'years';
  /** Optional comparison note shown under the value. */
  note?: Bilingual;
  tone?: 'positive' | 'negative' | 'neutral';
};

export type CaseStudy = {
  slug: string;
  title: Bilingual;
  summary: Bilingual;
  focus: Bilingual;
  context: Bilingual;
  problem: Bilingual;
  approach: Bilingual[];
  kpis: Kpi[];
  findings: Bilingual[];
  recommendations: Bilingual[];
  assumptions?: Bilingual[];
};

/* ---------------- Raw synthetic data used by the charts ---------------- */

export const months = {
  en: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
  ar: ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'],
};

export const branchData = {
  branches: [
    { en: 'Branch A', ar: 'الفرع أ' },
    { en: 'Branch B', ar: 'الفرع ب' },
  ] as Bilingual[],
  revenue: {
    a: [380, 395, 410, 402, 418, 425],
    b: [310, 318, 322, 315, 330, 335],
  },
  categories: [
    { name: { en: 'Beverages', ar: 'المشروبات' }, standardCostPct: 22, mixA: 40, mixB: 20 },
    { name: { en: 'Main dishes', ar: 'الأطباق الرئيسية' }, standardCostPct: 38, mixA: 40, mixB: 60 },
    { name: { en: 'Bakery', ar: 'المخبوزات' }, standardCostPct: 30, mixA: 20, mixB: 20 },
  ] as { name: Bilingual; standardCostPct: number; mixA: number; mixB: number }[],
  // Cost of sales as % of sales
  standardCostPct: { a: 30.0, b: 33.2 },
  actualCostPct: { a: 30.8, b: 36.8 },
};

export const budgetData = {
  revenueBudget: [480, 470, 520, 540, 560, 600, 620, 610, 580, 560, 590, 650],
  revenueActual: [465, 455, 530, 520, 548, 585],
  expenseBudget: [360, 355, 380, 390, 400, 420, 430, 425, 410, 400, 415, 445],
  expenseActual: [355, 362, 385, 401, 404, 426],
  /** Rolling forecast for Jul–Dec = budget × factor */
  scenarios: [
    { key: 'downside', name: { en: 'Downside', ar: 'متحفظ' }, revenueFactor: 0.93, expenseFactor: 0.98 },
    { key: 'base', name: { en: 'Base', ar: 'أساسي' }, revenueFactor: 0.98, expenseFactor: 1.0 },
    { key: 'upside', name: { en: 'Upside', ar: 'متفائل' }, revenueFactor: 1.03, expenseFactor: 1.01 },
  ] as { key: string; name: Bilingual; revenueFactor: number; expenseFactor: number }[],
};

export const investmentData = {
  investment: 1500,
  hurdleRate: 0.12,
  baseInflows: [320, 410, 460, 480, 490],
  scenarios: [
    { key: 'downside', name: { en: 'Downside', ar: 'متحفظ' }, factor: 0.8, note: { en: 'Inflows 20% below base', ar: 'تدفقات أقل من الأساسي بنسبة 20%' } },
    { key: 'base', name: { en: 'Base', ar: 'أساسي' }, factor: 1.0, note: { en: 'Management assumptions', ar: 'افتراضات الإدارة' } },
    { key: 'upside', name: { en: 'Upside', ar: 'متفائل' }, factor: 1.12, note: { en: 'Inflows 12% above base', ar: 'تدفقات أعلى من الأساسي بنسبة 12%' } },
  ] as { key: string; name: Bilingual; factor: number; note: Bilingual }[],
};

/* ---------------- Case study write-ups ---------------- */

export const caseStudies: CaseStudy[] = [
  {
    slug: 'branch-performance',
    title: { en: 'Branch Performance Analysis', ar: 'تحليل أداء الفروع' },
    focus: { en: 'Business performance · Cost analysis', ar: 'أداء الأعمال · تحليل التكاليف' },
    summary: {
      en: 'Why does one branch keep 6 points less of every sale than the other? Separating product mix from execution shows which half of the gap management can fix.',
      ar: 'لماذا يحتفظ أحد الفرعين بست نقاط أقل من كل عملية بيع مقارنة بالآخر؟ فصل أثر مزيج المنتجات عن أثر التنفيذ يوضح أي جزء من الفجوة يمكن للإدارة معالجته.',
    },
    context: {
      en: 'A fictional food-service business operates two branches with the same menu and the same standard recipe costs. Management reviews a half-year pack of revenue and cost of sales by branch and product category.',
      ar: 'شركة خدمات غذائية افتراضية تدير فرعين بقائمة الأصناف نفسها وتكاليف الوصفات المعيارية نفسها. تراجع الإدارة تقرير نصف سنوي للإيرادات وتكلفة المبيعات حسب الفرع وفئة المنتج.',
    },
    problem: {
      en: "Branch B's cost of sales runs at 36.8% of sales against 30.8% at Branch A. The first instinct is to blame waste or purchasing at Branch B, but nobody has checked how much of the gap simply comes from what each branch sells.",
      ar: 'تبلغ تكلفة المبيعات في الفرع ب 36.8% من المبيعات مقابل 30.8% في الفرع أ. الانطباع الأول هو تحميل الهدر أو المشتريات مسؤولية الفرق، لكن لم يتحقق أحد من حجم الفجوة الناتج ببساطة عن طبيعة ما يبيعه كل فرع.',
    },
    approach: [
      { en: 'Compare monthly revenue for both branches to confirm the trend is stable and not driven by one unusual month.', ar: 'مقارنة الإيرادات الشهرية للفرعين للتأكد من استقرار الاتجاه وعدم تأثره بشهر استثنائي.' },
      { en: 'Calculate each branch\'s standard cost % of sales: the cost it should have, given its own product mix and standard recipe costs.', ar: 'احتساب نسبة التكلفة المعيارية من المبيعات لكل فرع: التكلفة المفترضة وفق مزيج منتجاته وتكاليف الوصفات المعيارية.' },
      { en: 'Split the gap into a mix effect (difference in standard cost %) and an execution effect (actual minus standard at each branch).', ar: 'تقسيم الفجوة إلى أثر المزيج (الفرق في نسبة التكلفة المعيارية) وأثر التنفيذ (الفعلي ناقص المعياري في كل فرع).' },
      { en: 'Translate each effect into gross profit so management can see what is at stake in currency, not only in percentage points.', ar: 'تحويل كل أثر إلى مجمل ربح لتتمكن الإدارة من رؤية القيمة بالعملة وليس بالنقاط المئوية فقط.' },
    ],
    kpis: [
      { label: { en: 'H1 revenue — Branch A', ar: 'إيرادات النصف الأول — الفرع أ' }, value: 2430, format: 'k' },
      { label: { en: 'H1 revenue — Branch B', ar: 'إيرادات النصف الأول — الفرع ب' }, value: 1930, format: 'k', note: { en: '20.6% below Branch A', ar: 'أقل من الفرع أ بنسبة 20.6%' } },
      { label: { en: 'Cost of sales gap', ar: 'فجوة تكلفة المبيعات' }, value: 6.0, format: 'pp', note: { en: '36.8% vs 30.8% of sales', ar: '36.8% مقابل 30.8% من المبيعات' }, tone: 'negative' },
      { label: { en: 'Gap explained by product mix', ar: 'الجزء المفسَّر بمزيج المنتجات' }, value: 3.2, format: 'pp', note: { en: 'Not a control failure', ar: 'ليس خللًا رقابيًا' }, tone: 'neutral' },
    ],
    findings: [
      { en: 'Product mix explains 3.2 of the 6.0 points. Branch B sells 60% main dishes, the highest-cost category at a 38% standard cost, against 40% at Branch A. Its standard cost is 33.2% before anyone touches a recipe.', ar: 'يفسر مزيج المنتجات 3.2 نقطة من أصل 6.0. يبيع الفرع ب 60% أطباقًا رئيسية، وهي الفئة الأعلى تكلفة بنسبة معيارية 38%، مقابل 40% في الفرع أ. أي أن تكلفته المعيارية 33.2% قبل أي انحراف في التنفيذ.' },
      { en: 'Execution explains the other 2.8 points. Branch B runs 3.6 points above its own standard, while Branch A runs only 0.8 points above. That is the part worth investigating: portioning, waste, theft or supplier prices.', ar: 'يفسر التنفيذ النقاط الـ2.8 المتبقية. يتجاوز الفرع ب تكلفته المعيارية بـ3.6 نقطة، بينما يتجاوزها الفرع أ بـ0.8 نقطة فقط. هذا هو الجزء الجدير بالتحقيق: حجم الحصص أو الهدر أو الفاقد أو أسعار الموردين.' },
      { en: 'At Branch B\'s H1 revenue, the execution gap is worth about SAR 54k of gross profit; the mix gap about SAR 62k. Both matter, but they need different owners.', ar: 'بناءً على إيرادات الفرع ب في النصف الأول، تبلغ قيمة فجوة التنفيذ نحو 54 ألف ريال من مجمل الربح، وفجوة المزيج نحو 62 ألف ريال. كلاهما مهم، لكن لكل منهما مسؤول مختلف.' },
    ],
    recommendations: [
      { en: 'Give the 2.8-point execution gap to operations: run a stock count and portion audit at Branch B, and compare its supplier invoices with Branch A\'s.', ar: 'إسناد فجوة التنفيذ (2.8 نقطة) إلى العمليات: إجراء جرد ومراجعة لأحجام الحصص في الفرع ب، ومقارنة فواتير الموردين مع الفرع أ.' },
      { en: 'Treat the mix gap as a commercial decision, not a cost problem: review main-dish pricing and promote higher-margin beverages at Branch B.', ar: 'التعامل مع فجوة المزيج كقرار تجاري لا كمشكلة تكلفة: مراجعة تسعير الأطباق الرئيسية وتعزيز مبيعات المشروبات الأعلى هامشًا في الفرع ب.' },
      { en: 'Report actual vs standard cost % by branch every month, so the execution gap is tracked separately from mix from now on.', ar: 'إدراج التكلفة الفعلية مقابل المعيارية لكل فرع في التقرير الشهري، لمتابعة فجوة التنفيذ بمعزل عن أثر المزيج.' },
    ],
  },
  {
    slug: 'budget-forecast',
    title: { en: 'Budgeting & Rolling Forecast', ar: 'الموازنة والتوقعات المتجددة' },
    focus: { en: 'FP&A · Variance analysis · Scenarios', ar: 'التخطيط والتحليل المالي · الانحرافات · السيناريوهات' },
    summary: {
      en: 'Half-year results trail budget. A variance review and a three-scenario rolling forecast show what the full year will likely look like and which levers are still available.',
      ar: 'نتائج النصف الأول أقل من الموازنة. مراجعة الانحرافات مع توقعات متجددة بثلاثة سيناريوهات توضح الصورة المرجحة للسنة الكاملة والأدوات التي لا تزال متاحة للإدارة.',
    },
    context: {
      en: 'A fictional mid-sized company approved an annual budget of SAR 6.78m revenue and SAR 1.95m operating profit. At the end of June, management asks finance whether the year is still on track.',
      ar: 'شركة متوسطة الحجم افتراضية اعتمدت موازنة سنوية بإيرادات 6.78 مليون ريال وربح تشغيلي 1.95 مليون ريال. في نهاية يونيو، تسأل الإدارة الإدارة المالية: هل لا تزال السنة على المسار الصحيح؟',
    },
    problem: {
      en: 'H1 operating profit is SAR 770k against a budget of SAR 865k. The budget is now out of date as a target, but the business still needs a realistic view of the full year to plan hiring, purchasing and cash.',
      ar: 'بلغ الربح التشغيلي للنصف الأول 770 ألف ريال مقابل 865 ألف ريال في الموازنة. لم تعد الموازنة هدفًا واقعيًا، لكن الشركة لا تزال تحتاج إلى رؤية واقعية للسنة الكاملة لتخطيط التوظيف والمشتريات والسيولة.',
    },
    approach: [
      { en: 'Compare actual revenue and operating expenses with budget month by month, and isolate the months that drive the variance.', ar: 'مقارنة الإيرادات والمصروفات التشغيلية الفعلية بالموازنة شهرًا بشهر، وتحديد الأشهر المسببة للانحراف.' },
      { en: 'Decompose the H1 profit variance into its revenue shortfall and its expense overrun.', ar: 'تحليل انحراف الربح في النصف الأول إلى نقص الإيرادات وتجاوز المصروفات.' },
      { en: 'Build a rolling forecast for July–December under downside, base and upside assumptions, keeping H1 actuals fixed.', ar: 'بناء توقعات متجددة للفترة من يوليو إلى ديسمبر وفق سيناريوهات متحفظ وأساسي ومتفائل، مع تثبيت الفعلي للنصف الأول.' },
      { en: 'Present the full-year range against budget so management can decide which actions to take now.', ar: 'عرض نطاق نتائج السنة الكاملة مقارنة بالموازنة لتقرر الإدارة الإجراءات المطلوبة الآن.' },
    ],
    kpis: [
      { label: { en: 'H1 revenue vs budget', ar: 'إيرادات النصف الأول مقابل الموازنة' }, value: -2.1, format: 'pct', note: { en: 'SAR 3,103k vs 3,170k', ar: '3,103 ألف مقابل 3,170 ألف ريال' }, tone: 'negative' },
      { label: { en: 'H1 operating expenses vs budget', ar: 'المصروفات التشغيلية مقابل الموازنة' }, value: 1.2, format: 'pct', note: { en: 'SAR 2,333k vs 2,305k', ar: '2,333 ألف مقابل 2,305 ألف ريال' }, tone: 'negative' },
      { label: { en: 'H1 operating profit vs budget', ar: 'الربح التشغيلي مقابل الموازنة' }, value: -11.0, format: 'pct', note: { en: 'SAR 770k vs 865k', ar: '770 ألف مقابل 865 ألف ريال' }, tone: 'negative' },
      { label: { en: 'Full-year profit, base case', ar: 'ربح السنة الكاملة — السيناريو الأساسي' }, value: 1783, format: 'k', note: { en: 'Budget: SAR 1,950k', ar: 'الموازنة: 1,950 ألف ريال' } },
    ],
    findings: [
      { en: 'A small revenue miss becomes a large profit miss. Revenue is only 2.1% below budget, but because expenses ran 1.2% over, operating profit is 11.0% short. Operating leverage works in both directions.', ar: 'نقص بسيط في الإيرادات يتحول إلى نقص كبير في الربح. الإيرادات أقل من الموازنة بنسبة 2.1% فقط، لكن مع تجاوز المصروفات بنسبة 1.2% ينخفض الربح التشغيلي بنسبة 11.0%. الرافعة التشغيلية تعمل في الاتجاهين.' },
      { en: 'The shortfall is steady rather than sudden: revenue missed budget in five of six months, and only March came in ahead. A consistent pace slightly below plan is why the forecast should not assume a catch-up in H2.', ar: 'النقص مستمر وليس مفاجئًا: جاءت الإيرادات دون الموازنة في خمسة من ستة أشهر، ولم يتجاوزها سوى مارس. هذا الأداء الثابت دون الخطة بقليل هو سبب عدم افتراض تعويض الفجوة في النصف الثاني.' },
      { en: 'The full-year operating profit range is SAR 1.65m to 1.94m. Even the upside case lands slightly below the SAR 1.95m budget, so the original target is unlikely without action on costs.', ar: 'يتراوح الربح التشغيلي المتوقع للسنة الكاملة بين 1.65 و1.94 مليون ريال. حتى السيناريو المتفائل يقل قليلًا عن موازنة 1.95 مليون ريال، ما يعني صعوبة تحقيق الهدف الأصلي دون إجراءات على التكاليف.' },
    ],
    recommendations: [
      { en: 'Re-baseline expectations around the base case (about SAR 1.78m) and communicate it early, rather than carrying a budget everyone knows is out of reach.', ar: 'إعادة ضبط التوقعات حول السيناريو الأساسي (نحو 1.78 مليون ريال) وإعلانها مبكرًا، بدلًا من الاستمرار في موازنة يعلم الجميع صعوبة تحقيقها.' },
      { en: 'Focus on the expense side, where management has more direct control: review discretionary spend in the categories that overran most in April and February.', ar: 'التركيز على جانب المصروفات حيث تملك الإدارة سيطرة أكبر: مراجعة الإنفاق التقديري في البنود التي سجلت أكبر تجاوز للموازنة في أبريل وفبراير.' },
      { en: 'Set a downside trigger: if Q3 revenue tracks the downside path, freeze non-essential hiring and purchasing before the year-end cash position is affected.', ar: 'تحديد نقطة إنذار: إذا سارت إيرادات الربع الثالث وفق المسار المتحفظ، يتم تجميد التوظيف والمشتريات غير الضرورية قبل أن يتأثر وضع السيولة في نهاية العام.' },
    ],
  },
  {
    slug: 'cash-flow-investment',
    title: { en: 'Cash Flow & Investment Evaluation', ar: 'تقييم التدفقات النقدية والاستثمار' },
    focus: { en: 'Financial modeling · Valuation · Risk', ar: 'النمذجة المالية · التقييم · المخاطر' },
    summary: {
      en: 'A new branch clears the 12% hurdle rate in the base case, but only just. Scenario and sensitivity analysis shows the decision depends almost entirely on how confident management is in the first two years.',
      ar: 'يتجاوز فرع جديد معدل العائد المطلوب البالغ 12% في السيناريو الأساسي، لكن بهامش ضئيل. يوضح تحليل السيناريوهات والحساسية أن القرار يعتمد بشكل شبه كامل على مدى ثقة الإدارة في أول عامين.',
    },
    context: {
      en: 'A fictional company is considering opening a new branch. The fit-out, equipment and pre-opening costs total SAR 1.5m. Management has prepared five years of projected net cash inflows.',
      ar: 'تدرس شركة افتراضية افتتاح فرع جديد بتكلفة إجمالية 1.5 مليون ريال تشمل التجهيز والمعدات ومصروفات ما قبل التشغيل. أعدّت الإدارة توقعات لصافي التدفقات النقدية الداخلة لخمس سنوات.',
    },
    problem: {
      en: 'The base case looks positive, but the company has a limited cash buffer. Before committing, management needs to know how sensitive the result is to weaker trading, and what has to be true for the investment to pay off.',
      ar: 'يبدو السيناريو الأساسي إيجابيًا، لكن هامش السيولة لدى الشركة محدود. قبل الالتزام، تحتاج الإدارة إلى معرفة مدى حساسية النتيجة لضعف الأداء، وما الشروط اللازمة لكي يحقق الاستثمار عائده.',
    },
    approach: [
      { en: 'Lay out the projected cash flows and the cumulative cash position year by year.', ar: 'عرض التدفقات النقدية المتوقعة والرصيد النقدي التراكمي سنة بسنة.' },
      { en: 'Calculate NPV at the 12% hurdle rate, IRR, simple payback and discounted payback.', ar: 'احتساب صافي القيمة الحالية بمعدل 12%، ومعدل العائد الداخلي، وفترة الاسترداد البسيطة والمخصومة.' },
      { en: 'Run downside and upside scenarios, then a sensitivity grid across discount rates and inflow levels.', ar: 'تشغيل سيناريوهات متحفظة ومتفائلة، ثم جدول حساسية عبر معدلات خصم ومستويات تدفقات مختلفة.' },
      { en: 'Summarise the decision criteria and the assumptions that carry the most risk.', ar: 'تلخيص معايير القرار والافتراضات الأعلى مخاطرة.' },
    ],
    // KPI values for this case study are calculated live from investmentData.
    kpis: [],
    findings: [
      { en: 'In the base case the project returns slightly more than the 12% hurdle rate, with a small positive NPV. It creates value, but with very little room for error.', ar: 'في السيناريو الأساسي يحقق المشروع عائدًا يفوق معدل 12% بقليل مع صافي قيمة حالية موجبة صغيرة. أي أنه يخلق قيمة، لكن بهامش خطأ ضئيل جدًا.' },
      { en: 'A 20% shortfall in inflows turns the NPV clearly negative and the investment is not recovered on a discounted basis within five years.', ar: 'انخفاض التدفقات بنسبة 20% يحوّل صافي القيمة الحالية إلى سالب بوضوح، ولا يُسترد الاستثمار على أساس مخصوم خلال خمس سنوات.' },
      { en: 'The sensitivity grid shows the result is more exposed to inflow levels than to the discount rate. Validating early-year trading assumptions matters more than refining the cost of capital.', ar: 'يُظهر جدول الحساسية أن النتيجة أكثر تأثرًا بمستوى التدفقات من معدل الخصم. لذا فإن التحقق من افتراضات الأداء في السنوات الأولى أهم من تدقيق تكلفة رأس المال.' },
    ],
    recommendations: [
      { en: 'Do not approve on the base case alone. Ask for evidence behind years 1–2 inflows, such as comparable branch ramp-up data or a signed anchor contract.', ar: 'عدم الاعتماد على السيناريو الأساسي وحده للموافقة. طلب أدلة تدعم تدفقات السنتين الأولى والثانية، مثل بيانات نمو فروع مشابهة أو عقد رئيسي موقّع.' },
      { en: 'Consider staging the investment: a smaller initial fit-out reduces the amount at risk if the downside materialises.', ar: 'النظر في تنفيذ الاستثمار على مراحل: تجهيز أولي أصغر يقلل المبلغ المعرض للخطر إذا تحقق السيناريو المتحفظ.' },
      { en: 'If approved, set quarterly checkpoints against the base-case cash flows, with a pre-agreed review if two consecutive quarters fall below plan.', ar: 'في حال الموافقة، تحديد نقاط متابعة ربع سنوية مقابل تدفقات السيناريو الأساسي، مع مراجعة متفق عليها مسبقًا إذا جاء ربعان متتاليان دون الخطة.' },
    ],
    assumptions: [
      { en: 'Initial investment of SAR 1.5m, paid at the start of year 1.', ar: 'استثمار مبدئي 1.5 مليون ريال يُدفع في بداية السنة الأولى.' },
      { en: 'Five-year evaluation period with no terminal value, which is a deliberately conservative choice.', ar: 'فترة تقييم خمس سنوات دون قيمة نهائية، وهو اختيار متحفظ عن قصد.' },
      { en: '12% hurdle rate reflecting the company\'s required return for a new location.', ar: 'معدل عائد مطلوب 12% يعكس العائد الذي تشترطه الشركة لموقع جديد.' },
      { en: 'Cash flows are after operating costs and tax, and before financing.', ar: 'التدفقات النقدية بعد التكاليف التشغيلية والضرائب وقبل التمويل.' },
    ],
  },
];
