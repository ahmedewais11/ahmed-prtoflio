import type { Lang } from '../i18n/types';

/** Arabic uses Western digits (1, 2, 3), which is standard in Gulf business reporting. */
export const locale = (lang: Lang) => (lang === 'ar' ? 'ar-SA-u-nu-latn' : 'en-US');

const MINUS = '−';

/**
 * Keeps a leading + or − on the correct side inside Arabic (right-to-left) text.
 * Without it, "+1.2%" would display as "1.2%+".
 */
export function ltr(s: string, lang: Lang) {
  return lang === 'ar' && /^[+\-−]/.test(s) ? `\u200E${s}` : s;
}

export function fmtNum(n: number, lang: Lang, maxFrac = 0, minFrac = 0) {
  const s = new Intl.NumberFormat(locale(lang), {
    maximumFractionDigits: maxFrac,
    minimumFractionDigits: minFrac,
  })
    .format(n)
    .replace('-', MINUS);
  return ltr(s, lang);
}

/** Like fmtNum but always shows the sign: +12 / −12 */
export function fmtSigned(n: number, lang: Lang, maxFrac = 0, minFrac = 0) {
  return ltr(`${n > 0 ? '+' : ''}${fmtNum(n, lang, maxFrac, minFrac)}`, lang);
}

export function fmtMoney(n: number, lang: Lang, currency: string, frac = 2) {
  return ltr(new Intl.NumberFormat(locale(lang), {
    style: 'currency',
    currency,
    currencyDisplay: 'code',
    maximumFractionDigits: frac,
    minimumFractionDigits: frac,
  })
    .format(n)
    .replace(/-/, MINUS), lang);
}

/** ratio 0.25 -> "25.0%" */
export function fmtRatio(ratio: number, lang: Lang, digits = 1) {
  return `${fmtNum(ratio * 100, lang, digits, digits)}%`;
}

/** value already in percent, with sign: 1.2 -> "+1.2%" */
export function fmtSignedPct(pct: number, lang: Lang, digits = 1) {
  const sign = pct > 0 ? '+' : '';
  return ltr(`${sign}${fmtNum(pct, lang, digits, digits)}%`, lang);
}

/** thousands of SAR: 2430 -> "SAR 2,430k" / "2,430 ألف ريال" */
export function fmtK(k: number, lang: Lang, signed = false) {
  const sign = signed && k > 0 ? '+' : '';
  const num = `${sign}${fmtNum(k, lang, Math.abs(k) < 10 && k % 1 !== 0 ? 1 : 0)}`;
  return lang === 'ar' ? `${ltr(num, lang)} ألف ريال` : `SAR ${num}k`;
}

/** plain thousands number for tables & axes */
export function fmtPlainK(k: number, lang: Lang, signed = false) {
  const sign = signed && k > 0 ? '+' : '';
  return ltr(`${sign}${fmtNum(k, lang, 0)}`, lang);
}

export function fmtPp(pp: number, lang: Lang) {
  return lang === 'ar' ? `${fmtNum(pp, lang, 1, 1)} نقطة` : `${fmtNum(pp, lang, 1, 1)} pts`;
}

export function fmtYears(y: number, lang: Lang) {
  return lang === 'ar' ? `${fmtNum(y, lang, 1, 1)} سنة` : `${fmtNum(y, lang, 1, 1)} years`;
}
