import { describe, expect, it } from 'vitest';
import { breakEven, irr, npv, payback } from './finance';

describe('breakEven', () => {
  it('computes the textbook example', () => {
    const r = breakEven({ price: 50, variableCost: 30, fixedCosts: 100_000, currentUnits: 7_000 });
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    expect(r.contributionMargin).toBe(20);
    expect(r.contributionMarginRatio).toBeCloseTo(0.4);
    expect(r.breakEvenUnits).toBe(5_000);
    expect(r.breakEvenUnitsRounded).toBe(5_000);
    expect(r.breakEvenRevenue).toBe(250_000);
    expect(r.current?.marginOfSafetyUnits).toBe(2_000);
    expect(r.current?.marginOfSafetyRevenue).toBe(100_000);
    expect(r.current?.marginOfSafetyRatio).toBeCloseTo(100_000 / 350_000);
    expect(r.current?.profit).toBe(40_000);
  });

  it('rounds break-even units up to whole units', () => {
    const r = breakEven({ price: 10, variableCost: 7, fixedCosts: 1_000 });
    if (!r.ok) throw new Error('expected ok');
    expect(r.breakEvenUnits).toBeCloseTo(333.333, 2);
    expect(r.breakEvenUnitsRounded).toBe(334);
  });

  it('reports a negative margin of safety below break-even', () => {
    const r = breakEven({ price: 50, variableCost: 30, fixedCosts: 100_000, currentUnits: 4_000 });
    if (!r.ok) throw new Error('expected ok');
    expect(r.current?.marginOfSafetyUnits).toBe(-1_000);
    expect(r.current?.profit).toBe(-20_000);
  });

  it('refuses zero or negative contribution margins', () => {
    expect(breakEven({ price: 30, variableCost: 30, fixedCosts: 1 }).ok).toBe(false);
    expect(breakEven({ price: 20, variableCost: 30, fixedCosts: 1 }).ok).toBe(false);
  });

  it('handles zero fixed costs', () => {
    const r = breakEven({ price: 10, variableCost: 4, fixedCosts: 0 });
    if (!r.ok) throw new Error('expected ok');
    expect(r.breakEvenUnits).toBe(0);
  });
});

describe('investment metrics', () => {
  const flows = [-1000, 300, 400, 500, 200];
  it('npv', () => {
    expect(npv(0, flows)).toBe(400);
    expect(npv(0.1, flows)).toBeCloseTo(-1000 + 272.727 + 330.579 + 375.657 + 136.603, 2);
  });
  it('irr makes npv zero', () => {
    const r = irr(flows)!;
    expect(Math.abs(npv(r, flows))).toBeLessThan(1e-6);
  });
  it('payback', () => {
    expect(payback(flows)).toBeCloseTo(2.6);
    expect(payback([-1000, 100, 100])).toBeNull();
  });
});
