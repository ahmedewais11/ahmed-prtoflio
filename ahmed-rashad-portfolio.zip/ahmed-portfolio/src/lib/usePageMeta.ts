import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { useLang } from '../i18n/LanguageContext';
import { profile } from '../content/profile';

function setMeta(selector: string, attr: 'name' | 'property', key: string, content: string) {
  let el = document.head.querySelector<HTMLMetaElement>(selector);
  if (!el) {
    el = document.createElement('meta');
    el.setAttribute(attr, key);
    document.head.appendChild(el);
  }
  el.content = content;
}

function setLink(rel: string, href: string, hreflang?: string) {
  const sel = hreflang ? `link[rel="${rel}"][hreflang="${hreflang}"]` : `link[rel="${rel}"]:not([hreflang])`;
  let el = document.head.querySelector<HTMLLinkElement>(sel);
  if (!el) {
    el = document.createElement('link');
    el.rel = rel;
    if (hreflang) el.hreflang = hreflang;
    document.head.appendChild(el);
  }
  el.href = href;
}

/** Sets the browser tab title, search description, social tags and language alternates for a page. */
export function usePageMeta(title: string, description: string) {
  const { lang } = useLang();
  const { pathname } = useLocation();
  useEffect(() => {
    document.title = title;
    setMeta('meta[name="description"]', 'name', 'description', description);
    setMeta('meta[property="og:title"]', 'property', 'og:title', title);
    setMeta('meta[property="og:description"]', 'property', 'og:description', description);
    setMeta('meta[property="og:locale"]', 'property', 'og:locale', lang === 'ar' ? 'ar_SA' : 'en_US');
    const base = profile.siteUrl.replace(/\/$/, '');
    const rest = pathname.replace(/^\/(en|ar)/, '');
    setMeta('meta[property="og:url"]', 'property', 'og:url', base + pathname);
    setLink('canonical', base + pathname);
    setLink('alternate', `${base}/en${rest}`, 'en');
    setLink('alternate', `${base}/ar${rest}`, 'ar');
  }, [title, description, lang, pathname]);
}
