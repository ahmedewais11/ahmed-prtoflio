/**
 * Financial calculations used across the site.
 * Everything runs in the visitor's browser — no server, no API.
 */

/* ---------------- Break-even analysis ---------------- */

export type BreakEvenInput = {
  price: number;
  variableCost: number;
  fixedCosts: number;
  /** Optional: units currently sold. */
  currentUnits?: number;
};

export type BreakEvenResult =
  | {
      ok: true;
      contributionMargin: number; // per unit
      contributionMarginRatio: number; // 0..1
      breakEvenUnits: number; // exact (may be fractional)
      breakEvenUnitsRounded: number; // whole units needed to actually break even
      breakEvenRevenue: number;
      current?: {
        units: number;
        revenue: number;
        profit: number;
        marginOfSafetyUnits: number; // negative = below break-even
        marginOfSafetyRevenue: number;
        marginOfSafetyRatio: number; // share of current sales, can be negative
      };
    }
  | { ok: false; reason: 'nonPositiveMargin'; contributionMargin: number };

export function breakEven({ price, variableCost, fixedCosts, currentUnits }: BreakEvenInput): BreakEvenResult {
  const cm = price - variableCost;
  if (!(cm > 0)) return { ok: false, reason: 'nonPositiveMargin', contributionMargin: cm };

  const cmr = cm / price;
  const beUnits = fixedCosts / cm;
  const beRevenue = beUnits * price;

  const result: BreakEvenResult = {
    ok: true,
    contributionMargin: cm,
    contributionMarginRatio: cmr,
    breakEvenUnits: beUnits,
    breakEvenUnitsRounded: Math.ceil(beUnits - 1e-9),
    breakEvenRevenue: beRevenue,
  };

  if (currentUnits !== undefined && currentUnits > 0) {
    const revenue = currentUnits * price;
    const mosRevenue = revenue - beRevenue;
    result.current = {
      units: currentUnits,
      revenue,
      profit: currentUnits * cm - fixedCosts,
      marginOfSafetyUnits: currentUnits - beUnits,
      marginOfSafetyRevenue: mosRevenue,
      marginOfSafetyRatio: mosRevenue / revenue,
    };
  }
  return result;
}

/* ---------------- Investment appraisal ---------------- */

/** Net present value. cashFlows[0] is today (usually the negative investment). */
export function npv(rate: number, cashFlows: number[]): number {
  return cashFlows.reduce((sum, cf, t) => sum + cf / Math.pow(1 + rate, t), 0);
}

/** Internal rate of return by bisection. Returns null when there is no sign change. */
export function irr(cashFlows: number[]): number | null {
  let lo = -0.99;
  let hi = 10;
  let fLo = npv(lo, cashFlows);
  const fHi = npv(hi, cashFlows);
  if (fLo * fHi > 0) return null;
  for (let i = 0; i < 200; i++) {
    const mid = (lo + hi) / 2;
    const fMid = npv(mid, cashFlows);
    if (Math.abs(fMid) < 1e-9) return mid;
    if (fLo * fMid < 0) hi = mid;
    else {
      lo = mid;
      fLo = fMid;
    }
  }
  return (lo + hi) / 2;
}

/**
 * Payback period in years (with linear interpolation inside the year).
 * Pass a rate to get the discounted payback. Returns null if never paid back.
 */
export function payback(cashFlows: number[], rate = 0): number | null {
  let cumulative = cashFlows[0];
  if (cumulative >= 0) return 0;
  for (let t = 1; t < cashFlows.length; t++) {
    const cf = cashFlows[t] / Math.pow(1 + rate, t);
    if (cumulative + cf >= 0) return t - 1 + -cumulative / cf;
    cumulative += cf;
  }
  return null;
}

export function sum(values: number[]): number {
  return values.reduce((a, b) => a + b, 0);
}
