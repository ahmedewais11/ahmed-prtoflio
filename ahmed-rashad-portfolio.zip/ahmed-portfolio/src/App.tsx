import { Navigate, Route, Routes, useParams, Outlet, useLocation } from 'react-router-dom';
import { LanguageProvider, preferredLang } from './i18n/LanguageContext';
import { LANGS, type Lang } from './i18n/types';
import { Layout } from './components/Layout';
import { HomePage } from './pages/HomePage';
import { AboutPage } from './pages/AboutPage';
import { ExpertisePage } from './pages/ExpertisePage';
import { PortfolioPage } from './pages/PortfolioPage';
import { CaseStudyPage } from './pages/CaseStudyPage';
import { ToolsPage } from './pages/ToolsPage';
import { ContactPage } from './pages/ContactPage';
import { NotFoundPage } from './pages/NotFoundPage';

/**
 * Every page lives under /en/... or /ar/...  (e.g. /ar/portfolio).
 * Because the language is part of the address, it is kept while navigating,
 * and each language version can be shared and indexed by search engines.
 */
function LangRoot() {
  const { lang } = useParams();
  const { pathname } = useLocation();
  // An address without a language (e.g. /about) is sent to /en/about or /ar/about
  if (!LANGS.includes(lang as Lang)) return <Navigate to={`/${preferredLang()}${pathname}`} replace />;
  return (
    <LanguageProvider lang={lang as Lang}>
      <Outlet />
    </LanguageProvider>
  );
}

export function App() {
  return (
    <Routes>
      <Route path="/" element={<Navigate to={`/${preferredLang()}`} replace />} />
      <Route path=":lang" element={<LangRoot />}>
        <Route element={<Layout />}>
          <Route index element={<HomePage />} />
          <Route path="about" element={<AboutPage />} />
          <Route path="expertise" element={<ExpertisePage />} />
          <Route path="portfolio" element={<PortfolioPage />} />
          <Route path="portfolio/:slug" element={<CaseStudyPage />} />
          <Route path="tools" element={<ToolsPage />} />
          <Route path="contact" element={<ContactPage />} />
          <Route path="*" element={<NotFoundPage />} />
        </Route>
      </Route>
    </Routes>
  );
}
