/**
 * Runs automatically after `npm run build`. You never need to run it yourself.
 *
 * For every page in both languages it writes a copy of index.html with the right
 * <title>, description, language direction and social-sharing tags, e.g.
 *   dist/ar/about/index.html
 * Social networks (LinkedIn, WhatsApp, X) and search engines read these tags
 * without running JavaScript, so each shared link shows the correct preview.
 * It also writes dist/sitemap.xml.
 */
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { ui } from '../src/content/ui.ts';
import { profile } from '../src/content/profile.ts';
import { caseStudies } from '../src/content/caseStudies.ts';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const dist = join(root, 'dist');
const template = readFileSync(join(dist, 'index.html'), 'utf8');
const site = profile.siteUrl.replace(/\/$/, '');

const esc = (s) => s.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;');

const pages = [
  { path: '', meta: 'home' },
  { path: '/about', meta: 'about' },
  { path: '/expertise', meta: 'expertise' },
  { path: '/portfolio', meta: 'portfolio' },
  { path: '/tools', meta: 'tools' },
  { path: '/contact', meta: 'contact' },
  ...caseStudies.map((cs) => ({ path: `/portfolio/${cs.slug}`, caseStudy: cs })),
];

const urls = [];
for (const page of pages) {
  for (const lang of ['en', 'ar']) {
    const title = page.caseStudy
      ? `${page.caseStudy.title[lang]} | ${ui['meta.portfolio.title'][lang]}`
      : ui[`meta.${page.meta}.title`][lang];
    const desc = page.caseStudy ? page.caseStudy.summary[lang] : ui[`meta.${page.meta}.desc`][lang];
    const url = `${site}/${lang}${page.path}`;
    urls.push(url);

    let html = template
      .replace('<html lang="en" dir="ltr">', `<html lang="${lang}" dir="${lang === 'ar' ? 'rtl' : 'ltr'}">`)
      .replace(/<title>.*?<\/title>/, `<title>${esc(title)}</title>`)
      .replace(/(<meta name="description" content=")[^"]*/, `$1${esc(desc)}`)
      .replace(/(<meta property="og:title" content=")[^"]*/, `$1${esc(title)}`)
      .replace(/(<meta property="og:description" content=")[^"]*/, `$1${esc(desc)}`)
      .replace(/(<meta property="og:image" content=")[^"]*/, `$1${site}/og-image.png`)
      .replace(/(<meta property="og:locale" content=")[^"]*/, `$1${lang === 'ar' ? 'ar_SA' : 'en_US'}`)
      .replace(/(<meta property="og:locale:alternate" content=")[^"]*/, `$1${lang === 'ar' ? 'en_US' : 'ar_SA'}`)
      .replace(
        '</head>',
        [
          `    <meta property="og:url" content="${url}" />`,
          `    <link rel="canonical" href="${url}" />`,
          `    <link rel="alternate" hreflang="en" href="${site}/en${page.path}" />`,
          `    <link rel="alternate" hreflang="ar" href="${site}/ar${page.path}" />`,
          `    <link rel="alternate" hreflang="x-default" href="${site}/en${page.path}" />`,
          '  </head>',
        ].join('\n'),
      );

    const out = join(dist, lang, page.path, 'index.html');
    mkdirSync(dirname(out), { recursive: true });
    writeFileSync(out, html);
  }
}

// Root page: same as English home, with an absolute image URL
writeFileSync(join(dist, 'index.html'), template.replace(/(<meta property="og:image" content=")[^"]*/, `$1${site}/og-image.png`));

writeFileSync(
  join(dist, 'sitemap.xml'),
  `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls.map((u) => `  <url><loc>${u}</loc></url>`).join('\n')}\n</urlset>\n`,
);
writeFileSync(join(dist, 'robots.txt'), `User-agent: *\nAllow: /\n\nSitemap: ${site}/sitemap.xml\n`);

console.log(`Prerendered ${urls.length} pages for ${site}`);
if (site.includes('YOUR-SITE')) {
  console.log('Reminder: set siteUrl in src/content/profile.ts to your real web address, then rebuild.');
}
